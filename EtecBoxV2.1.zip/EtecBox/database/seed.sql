INSERT IGNORE INTO categoria (id_categoria, nome) VALUES
(1,'Trabalho'),(2,'Apresentação'),(3,'Notícias'),(4,'Casual'),(5,'Estudos'),(6,'Mostra/PF'),(7,'TCC');

INSERT IGNORE INTO usuario (id_usuario,nome,email,senha_hash,foto_perfil,tema,tipo) VALUES
(1,'Administrador EtecBox','admin@etecbox.local','$2y$12$FghJW6iLI8UiYJYLmcnEB.u4b7gU9GbaQ04UfBOiRliqTjnWWDH1m',NULL,'claro','admin'),
(2,'Aluno Demonstração','aluno@etecbox.local','$2y$12$WDRiyVwglpQ9PCS1cZ.LKuazTCT.FHPTM4bp7iqdz.UbZowTb.6Cm',NULL,'claro','usuario'),
(3,'Ana · Demonstração','ana@etecbox.local','$2y$12$WDRiyVwglpQ9PCS1cZ.LKuazTCT.FHPTM4bp7iqdz.UbZowTb.6Cm',NULL,'claro','usuario');

INSERT IGNORE INTO video
(id_video,id_usuario,id_categoria,titulo,arquivo_video,thumbnail,duracao_segundos,visualizacoes,data_publicacao,status) VALUES
(1,2,1,'Biblioteca escolar: organizando um banco de dados','assets/demo/demo_banco_v2.mp4','assets/demo/demo_banco_v2.jpg',36,0,DATE_SUB(NOW(), INTERVAL 6 DAY),'ativo'),
(2,3,2,'Entidade e relacionamento: do aluno ao vídeo','assets/demo/demo_mer_v2.mp4','assets/demo/demo_mer_v2.jpg',36,0,DATE_SUB(NOW(), INTERVAL 5 DAY),'ativo'),
(3,2,6,'Da ideia ao protótipo: um roteiro para a Mostra','assets/demo/demo_mostra_v2.mp4','assets/demo/demo_mostra_v2.jpg',36,0,DATE_SUB(NOW(), INTERVAL 4 DAY),'ativo'),
(4,3,5,'SQL na prática: buscando vídeos com SELECT','assets/demo/demo_sql_v2.mp4','assets/demo/demo_sql_v2.jpg',36,0,DATE_SUB(NOW(), INTERVAL 3 DAY),'ativo'),
(5,2,5,'HTML, CSS e JavaScript: o papel de cada um','assets/demo/demo_web_v2.mp4','assets/demo/demo_web_v2.jpg',36,0,DATE_SUB(NOW(), INTERVAL 2 DAY),'ativo'),
(6,3,2,'Como organizar a apresentação do seu projeto','assets/demo/demo_apresentacao_v2.mp4','assets/demo/demo_apresentacao_v2.jpg',36,0,DATE_SUB(NOW(), INTERVAL 1 DAY),'ativo');

INSERT IGNORE INTO inscricao (id_inscricao,id_seguidor,id_canal) VALUES
(1,2,3);
