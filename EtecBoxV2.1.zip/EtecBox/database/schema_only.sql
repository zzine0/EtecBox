SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS usuario (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  foto_perfil VARCHAR(255) NULL,
  data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  tema VARCHAR(10) NOT NULL DEFAULT 'claro',
  tipo VARCHAR(10) NOT NULL DEFAULT 'usuario',
  INDEX idx_usuario_tipo (tipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categoria (
  id_categoria INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS video (
  id_video INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  id_categoria INT NOT NULL,
  titulo VARCHAR(150) NOT NULL,
  arquivo_video VARCHAR(255) NOT NULL,
  thumbnail VARCHAR(255) NOT NULL,
  duracao_segundos INT NOT NULL DEFAULT 0,
  visualizacoes INT NOT NULL DEFAULT 0,
  data_publicacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status VARCHAR(10) NOT NULL DEFAULT 'ativo',
  INDEX idx_video_usuario (id_usuario),
  INDEX idx_video_categoria (id_categoria),
  INDEX idx_video_status_data (status, data_publicacao),
  CONSTRAINT fk_video_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
  CONSTRAINT fk_video_categoria FOREIGN KEY (id_categoria) REFERENCES categoria(id_categoria)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inscricao (
  id_inscricao INT AUTO_INCREMENT PRIMARY KEY,
  id_seguidor INT NOT NULL,
  id_canal INT NOT NULL,
  data_inscricao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_inscricao (id_seguidor, id_canal),
  INDEX idx_inscricao_canal (id_canal),
  CONSTRAINT fk_inscricao_seguidor FOREIGN KEY (id_seguidor) REFERENCES usuario(id_usuario) ON DELETE CASCADE,
  CONSTRAINT fk_inscricao_canal FOREIGN KEY (id_canal) REFERENCES usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS historico (
  id_historico INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  id_video INT NOT NULL,
  data_assistido DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_historico (id_usuario, id_video),
  INDEX idx_historico_data (id_usuario, data_assistido),
  CONSTRAINT fk_historico_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE,
  CONSTRAINT fk_historico_video FOREIGN KEY (id_video) REFERENCES video(id_video) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
