# EtecBox

Plataforma escolar para publicar e assistir a vídeos de trabalhos, apresentações e estudos.

## Como abrir

**XAMPP:** copie esta pasta para `C:\xampp\htdocs\etecbox`, inicie Apache e MySQL e acesse `http://localhost/etecbox/instalacao/setup.php`. Depois da instalação, abra `http://localhost/etecbox/`.

**Docker:** abra o terminal nesta pasta, execute `docker compose up -d --build` e aguarde a inicialização. Acesse `http://localhost:8080`.

O projeto precisa de PHP e MySQL/MariaDB. Abrir os arquivos PHP com dois cliques não executa o sistema.

## Onde encontrar cada parte

| Pasta ou arquivo | Conteúdo |
| --- | --- |
| `index.php` | Entrada do site; encaminha para a página inicial. |
| `paginas/` | Telas e ações organizadas por área. |
| `config/` | Configuração, conexão com o banco e identificação da equipe. |
| `includes/` | Funções comuns, sessão, cabeçalho e rodapé. |
| `assets/` | CSS, JavaScript, imagens e vídeos de demonstração. |
| `database/` | Estrutura e dados iniciais do banco. |
| `uploads/` | Arquivos enviados pelo site e exemplos antigos preservados. |
| `instalacao/` | Instalador e diagnóstico do ambiente. |
| `docker/` | Inicialização, verificação e reparo do banco no Docker. |
| `documentacao/` | Instalação detalhada, mapa do código, requisitos e verificações. |
| `materiais/` | Capturas de tela, prévia visual e artes de divulgação. |

## Para avaliar o projeto

1. Instale usando [o guia de instalação](documentacao/INSTALACAO.md).
2. Abra o site e teste busca, cadastro, envio de vídeo, canal e histórico.
3. Use [o mapa dos arquivos](documentacao/ESTRUTURA.md) para localizar o código de cada área.
4. Consulte [os recursos implementados](documentacao/REQUISITOS.md) e [as verificações realizadas](documentacao/VERIFICACAO.txt).

| Conta de demonstração | E-mail | Senha |
| --- | --- | --- |
| Administrador | `admin@etecbox.local` | `admin123` |
| Aluno | `aluno@etecbox.local` | `etecbox123` |
| Ana | `ana@etecbox.local` | `etecbox123` |

As contas usam a mesma tela de login. O tipo de usuário define o acesso à administração. Cada perfil também funciona como canal.

Os nomes da equipe e do professor podem ser preenchidos em `config/projeto.php`.

Para atualizar uma instalação existente, siga a seção de atualização do guia antes de copiar os arquivos.
