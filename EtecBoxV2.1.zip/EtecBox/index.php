<?php
$destino = 'paginas/inicio/home.php';
if (!empty($_SERVER['QUERY_STRING'])) {
    $destino .= '?' . $_SERVER['QUERY_STRING'];
}
header('Location: ' . $destino);
exit();
