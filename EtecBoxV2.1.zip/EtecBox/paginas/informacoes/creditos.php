<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
$projeto = require __DIR__ . '/../../config/projeto.php';
$tituloPagina = 'Créditos';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section reading-page">
    <div class="section-head">
        <div>
            <h1>Créditos</h1>
            <p>Quem e o que fazem parte da EtecBox.</p>
        </div>
    </div>
    <section class="reading-section">
        <h2>O projeto</h2>
        <dl class="credits-list">
            <dt>Criação e desenvolvimento</dt>
            <dd><?= $projeto['equipe'] ? textoSeguro(implode(', ', $projeto['equipe'])) : 'Equipe do projeto EtecBox' ?></dd>
            <dt>Contexto</dt>
            <dd>Projeto escolar · <?= textoSeguro($projeto['instituicao']) ?> · <?= textoSeguro( $projeto['ano'] ) ?></dd>
            <?php if ($projeto['orientacao'] !== ''): ?>
            <dt>Orientação</dt>
            <dd><?= textoSeguro( $projeto['orientacao'] ) ?></dd>
            <?php endif; ?>
            <dt>Conteúdos da comunidade</dt>
            <dd>Os vídeos pertencem aos respectivos criadores, identificados em cada canal.</dd>
        </dl>
    </section>
    <section class="reading-section">
        <h2>Identidade e interface</h2>
        <p>Marca e banner desenvolvidos para a EtecBox. A navegação usa padrões conhecidos de plataformas de vídeo: busca, menu lateral, capas e canais. O projeto é independente e não tem vínculo com o YouTube.</p>
    </section>
    <section class="reading-section">
        <h2>Vídeos de demonstração</h2>
        <p>Os exemplos incluídos são pequenos materiais educativos originais, com texto, código e diagramas. Não usam gravações de alunos, músicas comerciais ou vídeos de terceiros. São identificados como demonstração em cada publicação.</p>
    </section>
    <section class="reading-section">
        <h2>Tecnologias utilizadas</h2>
        <dl class="credits-list">
            <dt>PHP</dt>
            <dd>Regras do sistema, sessões e envio de arquivos.</dd>
            <dt>MySQL / MariaDB</dt>
            <dd>Contas, vídeos, categorias, inscrições e histórico.</dd>
            <dt>HTML, CSS e JavaScript</dt>
            <dd>Páginas, aparência e interações no navegador.</dd>
            <dt>FFmpeg / FFprobe</dt>
            <dd>Preparação dos clipes de exemplo e leitura de duração.</dd>
            <dt>Docker / XAMPP</dt>
            <dd>Opções para executar o projeto.</dd>
        </dl>
    </section>
    <section class="reading-section">
        <h2>Agradecimento</h2>
        <p>Aos alunos e professores que compartilham conhecimento, testam as telas e ajudam a melhorar o projeto.</p>
    </section>
    <a class="btn btn-ghost" href="<?= textoSeguro(endereco('paginas/informacoes/sobre.php')) ?>">Sobre a EtecBox</a>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
