<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
$tituloPagina = 'Sobre a EtecBox';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section reading-page">
    <img class="about-banner" src="<?= textoSeguro( endereco('assets/img/banner.svg') ) ?>" width="1600" height="400" alt="EtecBox — Feito na escola. Compartilhado aqui.">
    <h1>Sobre a EtecBox</h1>
    <p class="reading-intro">Um lugar para os trabalhos da escola continuarem sendo vistos depois da apresentação.</p>
    <p>Na EtecBox, alunos podem compartilhar vídeos de projetos, apresentações e materiais de estudo. Quem assiste encontra referências, conhece o trabalho de outras turmas e aprende com a comunidade.</p>
    <section class="reading-section">
        <h2>Por que esse projeto existe?</h2>
        <p>Muita coisa boa produzida na escola acaba espalhada em grupos de mensagens ou guardada no computador de alguém. A proposta é reunir esses conteúdos em uma plataforma organizada por categorias, com um canal para cada criador.</p>
    </section>
    <section class="reading-section">
        <h2>Como usar</h2>
        <div class="how-steps">
            <div><span class="step-number">01</span><strong>Encontre um assunto</strong>
                <p>Use a pesquisa ou escolha uma categoria. Você pode assistir sem criar uma conta.</p>
            </div>
            <div><span class="step-number">02</span><strong>Compartilhe o que criou</strong>
                <p>Crie sua conta, envie um vídeo, escolha a capa e a categoria. Ele aparece no seu canal e na página inicial.</p>
            </div>
            <div><span class="step-number">03</span><strong>Continue acompanhando</strong>
                <p>Inscreva-se nos canais que você gosta e use o histórico para voltar aos vídeos que assistiu.</p>
            </div>
        </div>
    </section>
    <section class="reading-section">
        <h2>Inspiração com autoria</h2>
        <p><strong>Ver → Aprender → Adaptar → Criar.</strong></p>
        <p>Use os conteúdos para entender ideias e construir o seu próprio trabalho. Dê crédito às referências, publique apenas o que você pode compartilhar e peça autorização às pessoas que aparecem nas gravações.</p>
    </section>
    <section class="reading-section">
        <h2>Um projeto escolar em desenvolvimento</h2>
        <p>A EtecBox foi criada para colocar em prática a construção de um sistema web com banco de dados: cadastro, publicação de vídeos, organização de conteúdo e administração.</p>
        <p>Vídeos marcados como <strong>Demonstração</strong> foram preparados para mostrar a plataforma funcionando. As contas e os exemplos desses materiais não representam alunos reais.</p>
        <p><a class="text-link" href="<?= textoSeguro( endereco('paginas/informacoes/creditos.php') ) ?>">Conheça os créditos do projeto</a></p>
    </section>
    <a class="btn btn-primary" href="<?= textoSeguro(endereco('paginas/inicio/home.php')) ?>">Explorar vídeos</a>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
