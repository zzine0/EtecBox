<?php
require_once __DIR__ . '/../../includes/bootstrap.php';

if (estaLogado()) {
    redirecionar('paginas/inicio/home.php');
}

$erros = [];
$nome = '';
$email = '';

if (formularioEnviado()) {
    verificarFormulario();
    $nome = trim((string) ($_POST['nome'] ?? ''));
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $senha = (string) ($_POST['senha'] ?? '');
    $confirmacao = (string) ($_POST['confirmacao'] ?? '');

    if ($nome === '' || strlen($nome) < 2 || strlen($nome) > 100) {
        $erros[] = 'Informe um nome entre 2 e 100 caracteres.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        $erros[] = 'Informe um e-mail válido.';
    }
    if (strlen($senha) < 6) {
        $erros[] = 'A senha deve possuir pelo menos 6 caracteres.';
    }
    if ($senha !== $confirmacao) {
        $erros[] = 'As senhas digitadas não coincidem.';
    }

    if (!$erros) {
        try {
            $conexao = banco();
            $verificacao = $conexao->prepare('SELECT id_usuario FROM usuario WHERE email = ? LIMIT 1');
            $verificacao->execute([$email]);
            if ($verificacao->fetch()) {
                $erros[] = 'Este e-mail já está cadastrado.';
            } else {
                $consulta = $conexao->prepare(
                    'INSERT INTO usuario (nome, email, senha_hash, tema, tipo)
                     VALUES (?, ?, ?, "claro", "usuario")'
                );
                $consulta->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT)]);
                $_SESSION['user_id'] = (int) $conexao->lastInsertId();
                session_regenerate_id(true);
                adicionarMensagem('success', 'Conta criada com sucesso. Bem-vindo(a) à EtecBox!');
                redirecionar('paginas/inicio/home.php');
            }
        } catch (Throwable $erro) {
            $erros[] = $erro->getMessage();
        }
    }
}

$tituloPagina = 'Criar conta';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container auth-layout">
    <section class="auth-art" aria-label="Conheça a EtecBox">
        <div class="brand-large">
            <img src="<?= textoSeguro(endereco('assets/img/logo.svg')) ?>" alt="">
            <span>EtecBox</span>
        </div>
        <h1 style="margin-top:26px">Sua próxima ideia pode começar aqui.</h1>
        <p class="muted">Compartilhe o que você criou e ajude outros alunos a descobrir novos caminhos.</p>
        <p><strong>Compartilhe. Inspire. Crie.</strong></p>
    </section>

    <section class="card auth-card" aria-labelledby="cadastro-title">
        <h1 id="cadastro-title">Criar conta</h1>
        <p class="muted">Leva menos de um minuto.</p>

        <?php foreach ($erros as $erro): ?>
        <div class="alert alert-danger"><?= textoSeguro($erro) ?></div>
        <?php endforeach; ?>

        <form method="post" class="form-grid" novalidate>
            <?= campoToken() ?>
            <div class="form-row">
                <label for="nome">Nome</label>
                <input class="input" id="nome" name="nome" maxlength="100" autocomplete="name" required value="<?= textoSeguro( $nome ) ?>">
            </div>
            <div class="form-row">
                <label for="email">E-mail</label>
                <input class="input" type="email" id="email" name="email" maxlength="150" autocomplete="email" required value="<?= textoSeguro( $email ) ?>">
            </div>
            <div class="form-row">
                <label for="senha">Senha</label>
                <input class="input" type="password" id="senha" name="senha" minlength="6" autocomplete="new-password" required>
                <p class="field-hint">Mínimo de 6 caracteres.</p>
            </div>
            <div class="form-row">
                <label for="confirmacao">Confirmar senha</label>
                <input class="input" type="password" id="confirmacao" name="confirmacao" minlength="6" autocomplete="new-password" required>
            </div>
            <button class="btn btn-primary btn-block" type="submit">Criar minha conta</button>
        </form>

        <p class="small muted" style="margin:18px 0 0;text-align:center">
            Já possui conta? <a href="<?= textoSeguro( endereco('paginas/acesso/login.php') ) ?>" style="color:var(--blue);font-weight:800">Entrar</a>
        </p>
    </section>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
