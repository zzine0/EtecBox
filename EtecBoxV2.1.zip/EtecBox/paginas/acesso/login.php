<?php
require_once __DIR__ . '/../../includes/bootstrap.php';

if (estaLogado()) {
    redirecionar('paginas/inicio/home.php');
}

$erros = [];
$email = '';

if (formularioEnviado()) {
    verificarFormulario();
    $email = trim((string) ($_POST['email'] ?? ''));
    $senha = (string) ($_POST['senha'] ?? '');

    $tentativas = $_SESSION['_login_attempts'] ?? ['count' => 0, 'since' => time()];
    if (time() - (int) $tentativas['since'] > 300) {
        $tentativas = ['count' => 0, 'since' => time()];
    }

    if ((int) $tentativas['count'] >= 10) {
        $erros[] = 'Muitas tentativas de login. Aguarde alguns minutos e tente novamente.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || $senha === '') {
        $erros[] = 'Informe um e-mail e uma senha válidos.';
    } else {
        try {
            $consulta = banco()->prepare('SELECT * FROM usuario WHERE email = ? LIMIT 1');
            $consulta->execute([$email]);
            $usuario = $consulta->fetch();

            if ($usuario && password_verify($senha, (string) $usuario['senha_hash'])) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = (int) $usuario['id_usuario'];
                unset($_SESSION['_login_attempts']);
                adicionarMensagem('success', 'Bem-vindo(a) à EtecBox, ' . $usuario['nome'] . '!');
                redirecionar('paginas/inicio/home.php');
            }

            $tentativas['count'] = (int) $tentativas['count'] + 1;
            $_SESSION['_login_attempts'] = $tentativas;
            $erros[] = 'E-mail ou senha inválidos.';
        } catch (Throwable $erro) {
            $erros[] = $erro->getMessage();
        }
    }
}

$tituloPagina = 'Entrar';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container auth-layout">
    <section class="auth-art" aria-label="Sobre a EtecBox">
        <div class="brand-large">
            <img src="<?= textoSeguro(endereco('assets/img/logo.svg')) ?>" alt="">
            <span>EtecBox</span>
        </div>
        <h1 style="margin-top:26px">Entre e continue compartilhando ideias.</h1>
        <p class="muted">Uma plataforma simples para reunir projetos, apresentações e trabalhos criados na ETEC.</p>
        <ul>
            <li>Publique seus vídeos.</li>
            <li>Conheça projetos de outros alunos.</li>
            <li>Organize seu histórico.</li>
            <li>Acompanhe canais que inspiram você.</li>
        </ul>
    </section>

    <section class="card auth-card" aria-labelledby="login-title">
        <h1 id="login-title">Entrar</h1>
        <p class="muted">Use seu e-mail e senha para acessar a plataforma.</p>

        <?php foreach ($erros as $erro): ?>
        <div class="alert alert-danger"><?= textoSeguro($erro) ?></div>
        <?php endforeach; ?>

        <form method="post" class="form-grid" novalidate>
            <?= campoToken() ?>
            <div class="form-row">
                <label for="email">E-mail</label>
                <input class="input" type="email" id="email" name="email" maxlength="150" autocomplete="email" required value="<?= textoSeguro( $email ) ?>">
            </div>
            <div class="form-row">
                <label for="senha">Senha</label>
                <input class="input" type="password" id="senha" name="senha" autocomplete="current-password" required>
            </div>
            <button class="btn btn-primary btn-block" type="submit">Entrar na EtecBox</button>
        </form>

        <p class="small muted" style="margin:18px 0 0;text-align:center">
            Ainda não tem conta? <a href="<?= textoSeguro( endereco('paginas/acesso/cadastro.php') ) ?>" style="color:var(--blue);font-weight:800">Criar conta</a>
        </p>
    </section>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
