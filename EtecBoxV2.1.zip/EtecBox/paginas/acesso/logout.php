<?php
require_once __DIR__ . '/../../includes/bootstrap.php';

if (!formularioEnviado()) {
    http_response_code(405);
    exit('Método não permitido.');
}
verificarFormulario();

$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $parametros = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $parametros['path'],
        $parametros['domain'] ?? '',
        (bool) $parametros['secure'],
        (bool) $parametros['httponly']
    );
}
session_destroy();
session_start();
adicionarMensagem('success', 'Você saiu da sua conta.');
redirecionar('paginas/inicio/home.php');
