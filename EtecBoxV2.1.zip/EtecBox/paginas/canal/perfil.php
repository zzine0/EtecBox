<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/video_card.php';

$id = (int) ($_GET['id'] ?? 0);
if ($id <= 0 && estaLogado()) {
    $id = (int) usuarioAtual()['id_usuario'];
}

try {
    $consulta = banco()->prepare(
        'SELECT u.*,
          (SELECT COUNT(*) FROM video v WHERE v.id_usuario=u.id_usuario AND v.status="ativo") AS total_videos,
          (SELECT COUNT(*) FROM inscricao i WHERE i.id_canal=u.id_usuario) AS total_inscritos
         FROM usuario u WHERE u.id_usuario=? LIMIT 1'
    );
    $consulta->execute([$id]);
    $perfil = $consulta->fetch();

    if (!$perfil) {
        http_response_code(404);
        $tituloPagina = 'Usuário não encontrado';
        require __DIR__ . '/../../includes/header.php';
        echo '<main class="container page-section"><div class="empty-state"><h1>Usuário não encontrado</h1><p>Este perfil não existe.</p><a class="btn btn-primary" href="' .
            textoSeguro(endereco('paginas/inicio/home.php')) .
            '">Voltar</a></div></main>';
        require __DIR__ . '/../../includes/footer.php';
        exit();
    }

    $v = banco()->prepare(
        'SELECT v.*, u.nome AS criador_nome, u.foto_perfil AS criador_foto, c.nome AS categoria_nome
         FROM video v
         JOIN usuario u ON u.id_usuario=v.id_usuario
         JOIN categoria c ON c.id_categoria=v.id_categoria
         WHERE v.id_usuario=? AND v.status="ativo"
         ORDER BY v.data_publicacao DESC'
    );
    $v->execute([$id]);
    $videos = $v->fetchAll();

    $inscrito = false;
    if (estaLogado() && (int) usuarioAtual()['id_usuario'] !== $id) {
        $s = banco()->prepare('SELECT id_inscricao FROM inscricao WHERE id_seguidor=? AND id_canal=?');
        $s->execute([(int) usuarioAtual()['id_usuario'], $id]);
        $inscrito = (bool) $s->fetch();
    }
} catch (Throwable $erro) {
    http_response_code(500);
    exit(textoSeguro($erro->getMessage()));
}

$tituloPagina = (string) $perfil['nome'];
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section stack-lg">
    <img class="profile-banner" src="<?= textoSeguro( endereco('assets/img/banner.svg') ) ?>" width="1600" height="400" alt="EtecBox — Feito na escola. Compartilhado aqui.">
    <section class="card profile-hero">
        <?php if (!empty($perfil['foto_perfil'])): ?>
        <img class="avatar-img avatar-xl" src="<?= textoSeguro( endereco((string) $perfil['foto_perfil']) ) ?>" alt="Foto de <?= textoSeguro((string) $perfil['nome']) ?>">
        <?php else: ?>
        <span class="avatar avatar-xl" aria-hidden="true"><?= textoSeguro( iniciais((string) $perfil['nome']) ) ?></span>
        <?php endif; ?>

        <div class="profile-hero__info">
            <h1><?= textoSeguro((string) $perfil['nome']) ?></h1>
            <div class="stat-inline">
                <span><strong><?= (int) $perfil['total_inscritos'] ?></strong> inscritos</span>
                <span><strong><?= (int) $perfil['total_videos'] ?></strong> vídeos</span>
                <span>na EtecBox desde <?= textoSeguro( date('m/Y', strtotime((string) $perfil['data_criacao'])) ) ?></span>
            </div>
        </div>

        <?php if (estaLogado() && (int) usuarioAtual()['id_usuario'] === $id): ?>
        <div class="flex flex-wrap">
            <a class="btn btn-ghost" href="<?= textoSeguro( endereco('paginas/conta/editar_perfil.php') ) ?>">Editar perfil</a>
            <a class="btn btn-ghost" href="<?= textoSeguro( endereco('paginas/conta/configuracoes.php') ) ?>">Configurações</a>
        </div>
        <?php elseif (estaLogado()): ?>
        <form method="post" action="<?= textoSeguro(endereco('paginas/canal/inscricao.php')) ?>">
            <?= campoToken() ?>
            <input type="hidden" name="id_canal" value="<?= $id ?>">
            <input type="hidden" name="retorno" value="<?= textoSeguro('paginas/canal/perfil.php?id=' . $id) ?>">
            <input type="hidden" name="acao" value="<?= $inscrito ? 'cancelar' : 'inscrever' ?>">
            <button class="btn <?= $inscrito ? 'btn-ghost' : 'btn-primary' ?>" type="submit">
                <?= $inscrito ? 'Inscrito ✓' : 'Inscrever-se' ?>
            </button>
        </form>
        <?php endif; ?>
    </section>

    <section>
        <div class="section-head">
            <div>
                <h2>Vídeos publicados</h2>
                <p>Conteúdos compartilhados por <?= textoSeguro((string) $perfil['nome']) ?>.</p>
            </div>
        </div>
        <?php if ($videos): ?>
        <div class="video-grid">
            <?php foreach ($videos as $video) { mostrarVideo($video); } ?>
        </div>
        <?php else: ?>
        <div class="empty-state">
            <h2>Nenhum vídeo publicado ainda.</h2>
            <p>Quando este usuário compartilhar um projeto, ele aparecerá aqui.</p>
        </div>
        <?php endif; ?>
    </section>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
