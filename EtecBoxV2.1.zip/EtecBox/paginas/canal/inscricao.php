<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirLogin();

if (!formularioEnviado()) {
    http_response_code(405);
    exit('Método não permitido.');
}
verificarFormulario();

$idSeguidor = (int) usuarioAtual()['id_usuario'];
$idCanal = (int) ($_POST['id_canal'] ?? 0);
$acao = (string) ($_POST['acao'] ?? '');
$retorno = (string) ($_POST['retorno'] ?? 'paginas/inicio/home.php');

if ($idCanal <= 0 || $idCanal === $idSeguidor) {
    adicionarMensagem('danger', 'Você não pode se inscrever no próprio canal.');
    redirecionar($retorno);
}

try {
    $verificacao = banco()->prepare('SELECT id_usuario FROM usuario WHERE id_usuario=?');
    $verificacao->execute([$idCanal]);
    if (!$verificacao->fetch()) {
        adicionarMensagem('danger', 'Canal não encontrado.');
        redirecionar('paginas/inicio/home.php');
    }

    if ($acao === 'cancelar') {
        $consulta = banco()->prepare('DELETE FROM inscricao WHERE id_seguidor=? AND id_canal=?');
        $consulta->execute([$idSeguidor, $idCanal]);
        adicionarMensagem('success', 'Inscrição cancelada.');
    } else {
        $consulta = banco()->prepare('INSERT IGNORE INTO inscricao (id_seguidor, id_canal) VALUES (?, ?)');
        $consulta->execute([$idSeguidor, $idCanal]);
        adicionarMensagem('success', 'Você se inscreveu neste canal.');
    }
} catch (Throwable $erro) {
    adicionarMensagem('danger', 'Não foi possível atualizar a inscrição.');
}

redirecionar($retorno);
