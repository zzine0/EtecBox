<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirLogin();

try {
    $consulta = banco()->prepare(
        'SELECT v.*, c.nome AS categoria_nome
         FROM video v
         JOIN categoria c ON c.id_categoria=v.id_categoria
         WHERE v.id_usuario=?
         ORDER BY v.data_publicacao DESC'
    );
    $consulta->execute([(int) usuarioAtual()['id_usuario']]);
    $videos = $consulta->fetchAll();
} catch (Throwable $erro) {
    $videos = [];
    $erro = $erro->getMessage();
}

$tituloPagina = 'Meus vídeos';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="section-head">
        <div>
            <h1>Meus vídeos</h1>
            <p>Gerencie os conteúdos que você publicou.</p>
        </div>
        <a class="btn btn-primary" href="<?= textoSeguro(endereco('paginas/videos/upload.php')) ?>">＋ Enviar vídeo</a>
    </div>

    <?php if (isset($erro)): ?>
    <div class="alert alert-danger"><?= textoSeguro($erro) ?></div>
    <?php endif; ?>

    <?php if ($videos): ?>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Vídeo</th>
                    <th>Categoria</th>
                    <th>Views</th>
                    <th>Status</th>
                    <th>Publicado</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($videos as $video): ?>
                <tr>
                    <td class="table-title"><strong><?= textoSeguro( (string) $video['titulo'] ) ?></strong></td>
                    <td><?= textoSeguro((string) $video['categoria_nome']) ?></td>
                    <td><?= textoSeguro(formatarVisualizacoes((int) $video['visualizacoes'])) ?></td>
                    <td><span class="status status-<?= textoSeguro( (string) $video['status'] ) ?>"><?= textoSeguro(ucfirst((string) $video['status'])) ?></span></td>
                    <td><?= textoSeguro( date('d/m/Y', strtotime((string) $video['data_publicacao'])) ) ?></td>
                    <td>
                        <div class="flex flex-wrap">
                            <?php if ($video['status'] === 'ativo'): ?>
                            <a class="btn btn-ghost btn-sm" href="<?= textoSeguro( endereco('paginas/videos/video.php?id=' . (int) $video['id_video']) ) ?>">Abrir</a>
                            <a class="btn btn-secondary btn-sm" href="<?= textoSeguro( endereco('paginas/videos/editar_video.php?id=' . (int) $video['id_video']) ) ?>">Editar</a>
                            <form method="post" action="<?= textoSeguro( endereco('paginas/videos/remover_video.php') ) ?>" data-confirm="Remover este vídeo? Ele deixará de aparecer e não poderá mais ser reproduzido.">
                                <?= campoToken() ?>
                                <input type="hidden" name="id_video" value="<?= (int) $video[ 'id_video' ] ?>">
                                <button class="btn btn-danger btn-sm" type="submit">Remover</button>
                            </form>
                            <?php else: ?>
                            <span class="small muted">Conteúdo removido</span>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <h2>Você ainda não publicou vídeos.</h2>
        <p>Compartilhe seu primeiro trabalho ou apresentação com a EtecBox.</p>
        <a class="btn btn-primary" href="<?= textoSeguro(endereco('paginas/videos/upload.php')) ?>">Enviar vídeo</a>
    </div>
    <?php endif; ?>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
