<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirLogin();

$usuario = usuarioAtual();
$nome = (string) $usuario['nome'];
$erros = [];

if (formularioEnviado()) {
    verificarFormulario();
    $nome = trim((string) ($_POST['nome'] ?? ''));

    if ($nome === '' || strlen($nome) < 2 || strlen($nome) > 100) {
        $erros[] = 'Informe um nome entre 2 e 100 caracteres.';
    }

    $novaFoto = null;
    if (!$erros) {
        try {
            if (
                !empty($_FILES['foto_perfil']) &&
                ($_FILES['foto_perfil']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE
            ) {
                $novaFoto = salvarFotoPerfil($_FILES['foto_perfil'], __DIR__ . '/../../uploads/perfis');
            }

            $caminhoFoto = $novaFoto ? 'uploads/perfis/' . $novaFoto : $usuario['foto_perfil'];
            $consultaGravacao = banco()->prepare(
                'UPDATE usuario SET nome=?, foto_perfil=? WHERE id_usuario=?'
            );
            $consultaGravacao->execute([$nome, $caminhoFoto, (int) $usuario['id_usuario']]);

            if ($novaFoto && !empty($usuario['foto_perfil'])) {
                apagarArquivo(__DIR__ . '/../../' . (string) $usuario['foto_perfil']);
            }

            adicionarMensagem('success', 'Perfil atualizado.');
            redirecionar('paginas/canal/perfil.php?id=' . (int) $usuario['id_usuario']);
        } catch (Throwable $erro) {
            apagarArquivo($novaFoto ? __DIR__ . '/../../uploads/perfis/' . $novaFoto : null);
            $erros[] = $erro->getMessage();
        }
    }
}

$tituloPagina = 'Editar perfil';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="section-head">
        <div>
            <h1>Editar perfil</h1>
            <p>Atualize o nome e a foto exibidos na EtecBox.</p>
        </div>
    </div>

    <div class="card card-pad" style="max-width:700px">
        <?php foreach ($erros as $erro): ?>
        <div class="alert alert-danger"><?= textoSeguro( $erro ) ?></div>
        <?php endforeach; ?>

        <form method="post" enctype="multipart/form-data" class="form-grid">
            <?= campoToken() ?>
            <div class="form-row">
                <label for="nome">Nome</label>
                <input class="input" id="nome" name="nome" maxlength="100" required value="<?= textoSeguro( $nome ) ?>">
            </div>

            <div class="form-row">
                <label>E-mail</label>
                <input class="input" value="<?= textoSeguro((string) $usuario['email']) ?>" disabled>
                <p class="field-hint">O e-mail de login não é alterado nesta versão do projeto.</p>
            </div>

            <div class="file-field photo-editor">
                <div class="photo-editor__preview" data-photo-preview><?= mostrarAvatar( $usuario['foto_perfil'] ?? null, (string) $usuario['nome'], 'xl' ) ?></div>
                <div class="form-row">
                    <label for="foto_perfil">Foto de perfil</label>
                    <input type="file" id="foto_perfil" name="foto_perfil" accept="image/jpeg,image/png,image/webp">
                    <p class="field-hint">JPG, PNG ou WebP, até 5 MB. A foto aparece com corte circular no centro.</p>
                </div>
            </div>

            <div class="form-actions">
                <button class="btn btn-primary" type="submit">Salvar perfil</button>
                <a class="btn btn-ghost" href="<?= textoSeguro( endereco('paginas/canal/perfil.php?id=' . (int) $usuario['id_usuario']) ) ?>">Cancelar</a>
            </div>
        </form>
    </div>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
