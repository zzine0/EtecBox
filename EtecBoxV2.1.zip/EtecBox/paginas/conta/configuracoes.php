<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirLogin();
$usuario = usuarioAtual();
$erros = [];
$temaEscolhido = (string) ($usuario['tema'] ?? 'claro');
if (formularioEnviado()) {
    verificarFormulario();
    $tema = (string) ($_POST['tema'] ?? '');
    if (!in_array($tema, ['claro', 'escuro'], true)) {
        $erros[] = 'Escolha um dos temas disponíveis.';
    } else {
        $temaEscolhido = $tema;
        try {
            $consultaGravacao = banco()->prepare('UPDATE usuario SET tema=? WHERE id_usuario=?');
            $consultaGravacao->execute([$tema, (int) $usuario['id_usuario']]);
            adicionarMensagem('success', 'Tema salvo.');
            redirecionar('paginas/conta/configuracoes.php');
        } catch (Throwable $erro) {
            $erros[] = 'Não foi possível salvar agora. Tente novamente.';
        }
    }
}
$opcoesTema = ['claro' => ['Claro', 'light'], 'escuro' => ['Escuro', 'dark']];
$tituloPagina = 'Configurações';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="section-head">
        <div>
            <h1>Configurações</h1>
            <p>Deixe a EtecBox do seu jeito.</p>
        </div>
    </div>
    <div class="card card-pad" style="max-width:720px">
        <?php foreach ($erros as $erro): ?>
        <div class="alert alert-danger" role="alert"><?= textoSeguro( $erro ) ?></div>
        <?php endforeach; ?>
        <form method="post" class="form-grid">
            <?= campoToken() ?>
            <fieldset style="border:0;padding:0;margin:0;min-width:0">
                <legend style="font-weight:600;margin-bottom:16px">Aparência</legend>
                <div class="settings-grid">
                    <?php foreach ($opcoesTema as $valor => $tema): ?>
                    <label class="theme-choice">
                        <input type="radio" name="tema" value="<?= textoSeguro( $valor ) ?>" data-theme-choice <?= $temaEscolhido === $valor ? 'checked' : '' ?> required>
                        <span class="theme-preview theme-preview--<?= textoSeguro($tema[1]) ?>">
                            <span class="theme-mock" aria-hidden="true"><span class="theme-mock-bar"></span><span class="theme-mock-side"></span><span class="theme-mock-grid"><i></i><i></i></span></span>
                            <span class="theme-name"><?= textoSeguro($tema[0]) ?></span>
                        </span>
                    </label>
                    <?php endforeach; ?>
                </div>
            </fieldset>
            <p class="theme-status" data-theme-status aria-live="polite">Seu tema acompanha a conta em todos os dispositivos.</p>
            <button class="btn btn-primary" type="submit" style="justify-self:start">Salvar preferência</button>
        </form>
        <hr class="settings-divider">
        <h2>Conta</h2>
        <p class="muted small">Criada em <?= textoSeguro( date('d/m/Y', strtotime((string) $usuario['data_criacao'])) ) ?>.</p>
        <div class="form-actions"><a class="btn btn-ghost" href="<?= textoSeguro( endereco('paginas/conta/editar_perfil.php') ) ?>">Editar perfil</a>
            <form method="post" action="<?= textoSeguro( endereco('paginas/acesso/logout.php') ) ?>"><?= campoToken() ?><button class="btn btn-ghost" type="submit">Sair da conta</button></form>
        </div>
    </div>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
