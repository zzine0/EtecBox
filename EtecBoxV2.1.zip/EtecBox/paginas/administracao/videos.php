<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirAdministrador();

try {
    $consultaLeitura = banco()->query(
        'SELECT v.*, u.nome AS usuario, c.nome AS categoria
         FROM video v
         JOIN usuario u ON u.id_usuario=v.id_usuario
         JOIN categoria c ON c.id_categoria=v.id_categoria
         ORDER BY v.data_publicacao DESC'
    );
    $videos = $consultaLeitura->fetchAll();
} catch (Throwable $erro) {
    $videos = [];
    $erro = $erro->getMessage();
}

$tituloPagina = 'Administrar vídeos';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="section-head">
        <div>
            <h1>Vídeos</h1>
            <p>Modere os conteúdos publicados na plataforma.</p>
        </div>
    </div>
    <?php require __DIR__ . '/_nav.php'; ?>
    <?php if (isset($erro)): ?>
    <div class="alert alert-danger"><?= textoSeguro($erro) ?></div>
    <?php endif; ?>

    <?php if ($videos): ?>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Vídeo</th>
                    <th>Autor</th>
                    <th>Categoria</th>
                    <th>Views</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($videos as $video): ?>
                <tr>
                    <td class="table-title"><strong><?= textoSeguro( (string) $video['titulo'] ) ?></strong></td>
                    <td><?= textoSeguro((string) $video['usuario']) ?></td>
                    <td><?= textoSeguro((string) $video['categoria']) ?></td>
                    <td><?= textoSeguro(formatarVisualizacoes((int) $video['visualizacoes'])) ?></td>
                    <td><span class="status status-<?= textoSeguro( (string) $video['status'] ) ?>"><?= textoSeguro(ucfirst((string) $video['status'])) ?></span></td>
                    <td>
                        <div class="flex flex-wrap">
                            <?php if ($video['status'] === 'ativo'): ?>
                            <a class="btn btn-ghost btn-sm" href="<?= textoSeguro( endereco('paginas/videos/video.php?id=' . (int) $video['id_video']) ) ?>">Abrir</a>
                            <form method="post" action="<?= textoSeguro( endereco('paginas/videos/remover_video.php') ) ?>" data-confirm="Remover este vídeo da EtecBox?">
                                <?= campoToken() ?>
                                <input type="hidden" name="id_video" value="<?= (int) $video[ 'id_video' ] ?>">
                                <button class="btn btn-danger btn-sm" type="submit">Remover</button>
                            </form>
                            <?php else: ?>
                            <span class="small muted">Já removido</span>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <p>Nenhum vídeo cadastrado.</p>
    </div>
    <?php endif; ?>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
