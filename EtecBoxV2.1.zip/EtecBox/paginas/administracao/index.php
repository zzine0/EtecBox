<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirAdministrador();

try {
    $conexao = banco();
    $resumo = [
        'usuarios' => (int) $conexao->query('SELECT COUNT(*) FROM usuario')->fetchColumn(),
        'videos' => (int) $conexao->query('SELECT COUNT(*) FROM video WHERE status="ativo"')->fetchColumn(),
        'views' => (int) $conexao
            ->query('SELECT COALESCE(SUM(visualizacoes),0) FROM video WHERE status="ativo"')
            ->fetchColumn()
    ];
    $consultaLeitura = $conexao->query(
        'SELECT v.id_video, v.titulo, v.status, v.data_publicacao, u.nome AS usuario, c.nome AS categoria
         FROM video v JOIN usuario u ON u.id_usuario=v.id_usuario JOIN categoria c ON c.id_categoria=v.id_categoria
         ORDER BY v.data_publicacao DESC LIMIT 8'
    );
    $recentes = $consultaLeitura->fetchAll();
} catch (Throwable $erro) {
    $resumo = ['usuarios' => 0, 'videos' => 0, 'views' => 0];
    $recentes = [];
    $erro = $erro->getMessage();
}

$tituloPagina = 'Painel administrativo';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="section-head">
        <div>
            <h1>Painel administrativo</h1>
            <p>Visão simples para organizar e moderar a EtecBox.</p>
        </div>
    </div>
    <?php require __DIR__ . '/_nav.php'; ?>
    <?php if (isset($erro)): ?>
    <div class="alert alert-danger"><?= textoSeguro($erro) ?></div>
    <?php endif; ?>

    <div class="stats-grid" style="margin-bottom:22px">
        <div class="stat-card"><span>Usuários</span><strong><?= $resumo['usuarios'] ?></strong></div>
        <div class="stat-card"><span>Vídeos ativos</span><strong><?= $resumo['videos'] ?></strong></div>
        <div class="stat-card"><span>Visualizações</span><strong><?= textoSeguro( formatarVisualizacoes($resumo['views']) ) ?></strong></div>
    </div>

    <section>
        <div class="section-head">
            <div>
                <h2>Publicações recentes</h2>
            </div>
        </div>
        <?php if ($recentes): ?>
        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Vídeo</th>
                        <th>Usuário</th>
                        <th>Categoria</th>
                        <th>Status</th>
                        <th>Data</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentes as $item): ?>
                    <tr>
                        <td class="table-title"><a href="<?= textoSeguro( endereco('paginas/videos/video.php?id=' . (int) $item['id_video']) ) ?>"><strong><?= textoSeguro((string) $item['titulo']) ?></strong></a></td>
                        <td><?= textoSeguro((string) $item['usuario']) ?></td>
                        <td><?= textoSeguro((string) $item['categoria']) ?></td>
                        <td><span class="status status-<?= textoSeguro( (string) $item['status'] ) ?>"><?= textoSeguro(ucfirst((string) $item['status'])) ?></span></td>
                        <td><?= textoSeguro( date('d/m/Y', strtotime((string) $item['data_publicacao'])) ) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="empty-state">
            <p>Nenhuma publicação ainda.</p>
        </div>
        <?php endif; ?>
    </section>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
