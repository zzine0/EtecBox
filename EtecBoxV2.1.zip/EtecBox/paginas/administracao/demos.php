<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirAdministrador();
$catalogo = json_decode(
    (string) file_get_contents(__DIR__ . '/../../assets/demo/catalogo.json'),
    true,
    512,
    JSON_THROW_ON_ERROR
);
$erro = null;
if (formularioEnviado()) {
    verificarFormulario();
    $conexao = banco();
    try {
        $conexao->beginTransaction();
        $adicionados = $atualizados = 0;
        foreach ($catalogo as $item) {
            if (
                !is_file(__DIR__ . '/../../' . $item['file']) ||
                !is_file(__DIR__ . '/../../' . $item['thumbnail'])
            ) {
                throw new RuntimeException(
                    'Arquivos de demonstração ausentes. Copie a pasta assets/demo completa.'
                );
            }
            $verificacao = $conexao->prepare('SELECT id_video FROM video WHERE arquivo_video=? LIMIT 1');
            $verificacao->execute([$item['file']]);
            if ($verificacao->fetch()) {
                continue;
            }
            $antigo = false;
            if (isset($item['old'], $item['oldtitle'])) {
                $busca = $conexao->prepare(
                    'SELECT id_video FROM video WHERE arquivo_video=? AND titulo=? LIMIT 1'
                );
                $busca->execute(['uploads/videos/' . $item['old'], $item['oldtitle']]);
                $antigo = $busca->fetch();
            }
            $categoria = $conexao->prepare('SELECT id_categoria FROM categoria WHERE nome=? LIMIT 1');
            $categoria->execute([$item['cat']]);
            $categoriaId = $categoria->fetchColumn();
            if (!$categoriaId) {
                throw new RuntimeException('A categoria ' . $item['cat'] . ' não foi encontrada.');
            }
            if ($antigo) {
                $consultaGravacao = $conexao->prepare(
                    'UPDATE video SET titulo=?, arquivo_video=?, thumbnail=?, duracao_segundos=?, id_categoria=? WHERE id_video=?'
                );
                $consultaGravacao->execute([
                    $item['title'],
                    $item['file'],
                    $item['thumbnail'],
                    $item['duration'],
                    (int) $categoriaId,
                    (int) $antigo['id_video']
                ]);
                $atualizados++;
            } else {
                $consultaGravacao = $conexao->prepare(
                    'INSERT INTO video (id_usuario,id_categoria,titulo,arquivo_video,thumbnail,duracao_segundos,visualizacoes,status) VALUES (?,?,?,?,?,?,0,"ativo")'
                );
                $consultaGravacao->execute([
                    (int) usuarioAtual()['id_usuario'],
                    (int) $categoriaId,
                    $item['title'],
                    $item['file'],
                    $item['thumbnail'],
                    $item['duration']
                ]);
                $adicionados++;
            }
        }
        $conexao->commit();
        adicionarMensagem(
            'success',
            $adicionados || $atualizados
                ? "Demonstrações prontas: {$adicionados} adicionadas e {$atualizados} atualizadas."
                : 'As demonstrações já estão cadastradas.'
        );
        redirecionar('paginas/administracao/demos.php');
    } catch (Throwable $erro) {
        if ($conexao->inTransaction()) {
            $conexao->rollBack();
        }
        $erro = $erro->getMessage();
    }
}
$tituloPagina = 'Demonstrações';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <?php require __DIR__ . '/_nav.php'; ?>
    <div class="section-head">
        <div>
            <h1>Vídeos de demonstração</h1>
            <p>Seis exemplos curtos para apresentar a EtecBox.</p>
        </div>
    </div>
    <?php if ($erro): ?>
    <div class="alert alert-danger" role="alert"><?= textoSeguro( $erro ) ?></div>
    <?php endif; ?>
    <div class="card card-pad" style="margin-bottom:28px">
        <p>Inclui os exemplos que ainda não existem e atualiza os três clipes originais que continuam com o título de demonstração. Seus outros vídeos, usuários e histórico são preservados.</p>
        <p class="small muted">Clipes de 36 segundos, sem narração. Publicações novas ficam neste canal e começam com zero visualizações. Exemplos removidos não são reativados. Você pode executar esta ação novamente sem duplicar os clipes cadastrados.</p>
        <form method="post"><?= campoToken() ?><button type="submit" class="btn btn-primary">Adicionar ou atualizar demonstrações</button></form>
    </div>
    <div class="video-grid">
        <?php foreach ( $catalogo as $item ): ?>
        <article class="video-card"><video class="video-player" controls playsinline preload="none" poster="<?= textoSeguro( endereco($item['thumbnail']) ) ?>">
                <source src="<?= textoSeguro( endereco($item['file']) ) ?>" type="video/mp4">
            </video>
            <h3 style="margin-top:12px"><?= textoSeguro( $item['title'] ) ?></h3>
            <p class="meta-line"><?= textoSeguro( $item['cat'] ) ?> · 0:36 · Demonstração</p>
        </article>
        <?php endforeach; ?>
    </div>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
