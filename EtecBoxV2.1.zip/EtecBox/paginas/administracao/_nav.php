<nav class="admin-nav" aria-label="Administração">
    <a href="<?= textoSeguro(endereco('paginas/administracao/index.php')) ?>">Resumo</a>
    <a href="<?= textoSeguro(endereco('paginas/administracao/videos.php')) ?>">Vídeos</a>
    <a href="<?= textoSeguro(endereco('paginas/administracao/usuarios.php')) ?>">Usuários</a>
    <a href="<?= textoSeguro(endereco('paginas/administracao/demos.php')) ?>">Demonstrações</a>
</nav>
