<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirAdministrador();

try {
    $consultaLeitura = banco()->query(
        'SELECT u.*,
          (SELECT COUNT(*) FROM video v WHERE v.id_usuario=u.id_usuario AND v.status="ativo") AS videos,
          (SELECT COUNT(*) FROM inscricao i WHERE i.id_canal=u.id_usuario) AS inscritos
         FROM usuario u
         ORDER BY u.data_criacao DESC'
    );
    $usuarios = $consultaLeitura->fetchAll();
} catch (Throwable $erro) {
    $usuarios = [];
    $erro = $erro->getMessage();
}

$tituloPagina = 'Administrar usuários';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="section-head">
        <div>
            <h1>Usuários</h1>
            <p>Consulte as contas cadastradas na EtecBox.</p>
        </div>
    </div>
    <?php require __DIR__ . '/_nav.php'; ?>
    <?php if (isset($erro)): ?>
    <div class="alert alert-danger"><?= textoSeguro($erro) ?></div>
    <?php endif; ?>

    <?php if ($usuarios): ?>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Tipo</th>
                    <th>Vídeos</th>
                    <th>Inscritos</th>
                    <th>Conta criada</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $u): ?>
                <tr>
                    <td><strong><?= textoSeguro((string) $u['nome']) ?></strong></td>
                    <td><?= textoSeguro((string) $u['email']) ?></td>
                    <td><?= textoSeguro((string) $u['tipo']) ?></td>
                    <td><?= (int) $u['videos'] ?></td>
                    <td><?= (int) $u['inscritos'] ?></td>
                    <td><?= textoSeguro(date('d/m/Y', strtotime((string) $u['data_criacao']))) ?></td>
                    <td><a class="btn btn-ghost btn-sm" href="<?= textoSeguro( endereco('paginas/canal/perfil.php?id=' . (int) $u['id_usuario']) ) ?>">Ver canal</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <p>Nenhum usuário cadastrado.</p>
    </div>
    <?php endif; ?>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
