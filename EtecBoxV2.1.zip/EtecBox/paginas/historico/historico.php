<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/video_card.php';
exigirLogin();

try {
    $consulta = banco()->prepare(
        'SELECT v.*, u.nome AS criador_nome, u.foto_perfil AS criador_foto, c.nome AS categoria_nome, h.data_assistido
         FROM historico h
         JOIN video v ON v.id_video=h.id_video
         JOIN usuario u ON u.id_usuario=v.id_usuario
         JOIN categoria c ON c.id_categoria=v.id_categoria
         WHERE h.id_usuario=? AND v.status="ativo"
         ORDER BY h.data_assistido DESC'
    );
    $consulta->execute([(int) usuarioAtual()['id_usuario']]);
    $videos = $consulta->fetchAll();
} catch (Throwable $erro) {
    $videos = [];
    $erro = $erro->getMessage();
}

$tituloPagina = 'Histórico';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="section-head">
        <div>
            <h1>Histórico</h1>
            <p>Vídeos que você assistiu recentemente.</p>
        </div>
    </div>

    <?php if (isset($erro)): ?>
    <div class="alert alert-danger"><?= textoSeguro($erro) ?></div>
    <?php endif; ?>

    <?php if ($videos): ?>
    <div class="video-grid">
        <?php foreach ($videos as $video) { mostrarVideo($video); } ?>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <h2>Seu histórico está vazio.</h2>
        <p>Quando você assistir a um vídeo, ele aparecerá aqui para ficar fácil encontrar novamente.</p>
        <a class="btn btn-primary" href="<?= textoSeguro(endereco('paginas/inicio/home.php')) ?>">Explorar vídeos</a>
    </div>
    <?php endif; ?>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
