<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirLogin();

$id = (int) ($_GET['id'] ?? 0);
$erros = [];

try {
    $consulta = banco()->prepare('SELECT * FROM video WHERE id_video=? LIMIT 1');
    $consulta->execute([$id]);
    $video = $consulta->fetch();
    if (
        !$video ||
        ((int) $video['id_usuario'] !== (int) usuarioAtual()['id_usuario'] && !ehAdministrador())
    ) {
        http_response_code(403);
        exit('Você não pode editar este vídeo.');
    }
    $consultaLeitura = banco()->query('SELECT id_categoria,nome FROM categoria ORDER BY id_categoria');
    $categorias = $consultaLeitura->fetchAll();
} catch (Throwable $erro) {
    exit(textoSeguro($erro->getMessage()));
}

$titulo = (string) $video['titulo'];
$idCategoria = (int) $video['id_categoria'];

if (formularioEnviado()) {
    verificarFormulario();
    $titulo = trim((string) ($_POST['titulo'] ?? ''));
    $idCategoria = (int) ($_POST['id_categoria'] ?? 0);

    if ($titulo === '' || strlen($titulo) > 150) {
        $erros[] = 'Informe um título com até 150 caracteres.';
    }
    $validCat = banco()->prepare('SELECT id_categoria FROM categoria WHERE id_categoria=?');
    $validCat->execute([$idCategoria]);
    if (!$validCat->fetch()) {
        $erros[] = 'Selecione uma categoria válida.';
    }

    $novaCapa = null;
    if (!$erros) {
        try {
            if (
                !empty($_FILES['thumbnail']) &&
                ($_FILES['thumbnail']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE
            ) {
                $novaCapa = salvarArquivo(
                    $_FILES['thumbnail'],
                    __DIR__ . '/../../uploads/thumbnails',
                    ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'],
                    MAX_IMAGE_BYTES,
                    'thumb'
                );
            }

            $caminhoCapa = $novaCapa ? 'uploads/thumbnails/' . $novaCapa : (string) $video['thumbnail'];

            $consultaGravacao = banco()->prepare(
                'UPDATE video SET titulo=?, id_categoria=?, thumbnail=? WHERE id_video=?'
            );
            $consultaGravacao->execute([$titulo, $idCategoria, $caminhoCapa, $id]);

            if ($novaCapa && !str_starts_with((string) $video['thumbnail'], 'uploads/thumbnails/demo_')) {
                apagarArquivo(__DIR__ . '/../../' . (string) $video['thumbnail']);
            }

            adicionarMensagem('success', 'Informações do vídeo atualizadas.');
            redirecionar('paginas/canal/meus_videos.php');
        } catch (Throwable $erro) {
            apagarArquivo($novaCapa ? __DIR__ . '/../../uploads/thumbnails/' . $novaCapa : null);
            $erros[] = $erro->getMessage();
        }
    }
}

$tituloPagina = 'Editar vídeo';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="section-head">
        <div>
            <h1>Editar vídeo</h1>
            <p>Altere o título, a categoria ou a thumbnail.</p>
        </div>
    </div>

    <div class="card card-pad" style="max-width:720px">
        <?php foreach ($erros as $erro): ?>
        <div class="alert alert-danger"><?= textoSeguro( $erro ) ?></div>
        <?php endforeach; ?>
        <form method="post" enctype="multipart/form-data" class="form-grid">
            <?= campoToken() ?>
            <div class="form-row">
                <label for="titulo">Título</label>
                <input class="input" id="titulo" name="titulo" maxlength="150" required value="<?= textoSeguro( $titulo ) ?>">
            </div>
            <div class="form-row">
                <label for="id_categoria">Categoria</label>
                <select class="select" id="id_categoria" name="id_categoria" required>
                    <?php foreach ($categorias as $categoria): ?>
                    <option value="<?= (int) $categoria['id_categoria'] ?>" <?= $idCategoria === (int) $categoria['id_categoria'] ? 'selected' : '' ?>><?= textoSeguro((string) $categoria['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row">
                <label>Thumbnail atual</label>
                <img src="<?= textoSeguro( endereco((string) $video['thumbnail']) ) ?>" alt="" style="max-width:300px;border-radius:12px">
            </div>
            <div class="form-row file-field">
                <label for="thumbnail">Trocar thumbnail (opcional)</label>
                <input type="file" id="thumbnail" name="thumbnail" accept="image/jpeg,image/png,image/webp">
                <div class="thumb-preview" data-thumb-preview></div>
            </div>
            <div class="form-actions">
                <button class="btn btn-primary" type="submit">Salvar alterações</button>
                <a class="btn btn-ghost" href="<?= textoSeguro(endereco('paginas/canal/meus_videos.php')) ?>">Cancelar</a>
            </div>
        </form>
    </div>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
