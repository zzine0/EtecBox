<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirLogin();

if (!formularioEnviado()) {
    http_response_code(405);
    exit('Método não permitido.');
}
verificarFormulario();

$id = (int) ($_POST['id_video'] ?? 0);

try {
    $consulta = banco()->prepare('SELECT id_usuario, status FROM video WHERE id_video=? LIMIT 1');
    $consulta->execute([$id]);
    $video = $consulta->fetch();

    if (!$video) {
        adicionarMensagem('danger', 'Vídeo não encontrado.');
        redirecionar('paginas/canal/meus_videos.php');
    }

    if ((int) $video['id_usuario'] !== (int) usuarioAtual()['id_usuario'] && !ehAdministrador()) {
        http_response_code(403);
        exit('Você não possui permissão para remover este vídeo.');
    }

    $consultaGravacao = banco()->prepare('UPDATE video SET status="removido" WHERE id_video=?');
    $consultaGravacao->execute([$id]);
    adicionarMensagem('success', 'Vídeo removido. Ele não aparece mais na plataforma.');
} catch (Throwable $erro) {
    adicionarMensagem('danger', 'Não foi possível remover o vídeo.');
}

redirecionar(ehAdministrador() ? 'paginas/administracao/videos.php' : 'paginas/canal/meus_videos.php');
