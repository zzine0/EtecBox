<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
exigirLogin();

$erros = [];
$titulo = '';
$idCategoria = 0;

try {
    $consultaLeitura = banco()->query('SELECT id_categoria, nome FROM categoria ORDER BY id_categoria');
    $categorias = $consultaLeitura->fetchAll();
} catch (Throwable $erro) {
    $categorias = [];
    $erros[] = $erro->getMessage();
}

if (formularioEnviado()) {
    verificarFormulario();

    $titulo = trim((string) ($_POST['titulo'] ?? ''));
    $idCategoria = (int) ($_POST['id_categoria'] ?? 0);
    $duracaoCliente = (int) ($_POST['duracao_cliente'] ?? 0);

    if ($titulo === '' || strlen($titulo) > 150) {
        $erros[] = 'Informe um título com até 150 caracteres.';
    }

    try {
        $conexao = banco();
        $cat = $conexao->prepare('SELECT id_categoria FROM categoria WHERE id_categoria = ?');
        $cat->execute([$idCategoria]);
        if (!$cat->fetch()) {
            $erros[] = 'Selecione uma categoria válida.';
        }
    } catch (Throwable $erro) {
        $erros[] = $erro->getMessage();
    }

    if (
        empty($_FILES['arquivo_video']) ||
        ($_FILES['arquivo_video']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE
    ) {
        $erros[] = 'Selecione o arquivo de vídeo.';
    }
    if (
        empty($_FILES['thumbnail']) ||
        ($_FILES['thumbnail']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE
    ) {
        $erros[] = 'Selecione uma thumbnail.';
    }

    $nomeVideo = null;
    $nomeCapa = null;

    if (!$erros) {
        try {
            $nomeVideo = salvarArquivo(
                $_FILES['arquivo_video'],
                __DIR__ . '/../../uploads/videos',
                ['video/mp4' => 'mp4', 'video/webm' => 'webm', 'video/ogg' => 'ogv'],
                MAX_VIDEO_BYTES,
                'video'
            );

            $nomeCapa = salvarArquivo(
                $_FILES['thumbnail'],
                __DIR__ . '/../../uploads/thumbnails',
                ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'],
                MAX_IMAGE_BYTES,
                'thumb'
            );

            $duracao = duracaoDoVideo(__DIR__ . '/../../uploads/videos/' . $nomeVideo, $duracaoCliente);

            $consulta = banco()->prepare(
                'INSERT INTO video
                 (id_usuario, id_categoria, titulo, arquivo_video, thumbnail, duracao_segundos, visualizacoes, status)
                 VALUES (?, ?, ?, ?, ?, ?, 0, "ativo")'
            );
            $consulta->execute([
                (int) usuarioAtual()['id_usuario'],
                $idCategoria,
                $titulo,
                'uploads/videos/' . $nomeVideo,
                'uploads/thumbnails/' . $nomeCapa,
                $duracao
            ]);

            $id = (int) banco()->lastInsertId();
            adicionarMensagem('success', 'Vídeo publicado com sucesso!');
            redirecionar('paginas/videos/video.php?id=' . $id);
        } catch (Throwable $erro) {
            apagarArquivo($nomeVideo ? __DIR__ . '/../../uploads/videos/' . $nomeVideo : null);
            apagarArquivo($nomeCapa ? __DIR__ . '/../../uploads/thumbnails/' . $nomeCapa : null);
            $erros[] = $erro->getMessage();
        }
    }
}

$tituloPagina = 'Enviar vídeo';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="section-head">
        <div>
            <h1>Enviar vídeo</h1>
            <p>Compartilhe um trabalho, apresentação ou projeto com a comunidade.</p>
        </div>
    </div>

    <div class="card card-pad" style="max-width:760px">
        <?php foreach ($erros as $erro): ?>
        <div class="alert alert-danger"><?= textoSeguro($erro) ?></div>
        <?php endforeach; ?>

        <form method="post" enctype="multipart/form-data" class="form-grid">
            <?= campoToken() ?>
            <input type="hidden" name="duracao_cliente" id="duracao_cliente" value="0">

            <div class="form-row">
                <label for="titulo">Título do vídeo</label>
                <input class="input" id="titulo" name="titulo" maxlength="150" required value="<?= textoSeguro( $titulo ) ?>" placeholder="Ex.: Projeto de Banco de Dados — Biblioteca">
            </div>

            <div class="form-row">
                <label for="id_categoria">Categoria</label>
                <select class="select" id="id_categoria" name="id_categoria" required>
                    <option value="">Selecione</option>
                    <?php foreach ($categorias as $categoria): ?>
                    <option value="<?= (int) $categoria['id_categoria'] ?>" <?= $idCategoria === (int) $categoria['id_categoria'] ? 'selected' : '' ?>>
                        <?= textoSeguro((string) $categoria['nome']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-row file-field">
                <label for="arquivo_video">Arquivo de vídeo</label>
                <input type="file" id="arquivo_video" name="arquivo_video" accept="video/mp4,video/webm,video/ogg" required>
                <p class="field-hint">MP4, WebM ou OGG. Limite configurado: 500 MB.</p>
                <p class="field-hint" data-duration-preview aria-live="polite"></p>
            </div>

            <div class="form-row file-field">
                <label for="thumbnail">Thumbnail</label>
                <input type="file" id="thumbnail" name="thumbnail" accept="image/jpeg,image/png,image/webp" required>
                <p class="field-hint">JPG, PNG ou WebP. Recomendado: proporção 16:9.</p>
                <div class="thumb-preview" data-thumb-preview></div>
            </div>

            <div class="alert alert-info">
                <strong>Lembrete:</strong> a EtecBox foi criada para inspiração e troca de conhecimento. Publique apenas conteúdos que você pode compartilhar.
            </div>

            <div class="form-actions">
                <button class="btn btn-primary" type="submit">Publicar vídeo</button>
                <a class="btn btn-ghost" href="<?= textoSeguro(endereco('paginas/inicio/home.php')) ?>">Cancelar</a>
            </div>
        </form>
    </div>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
