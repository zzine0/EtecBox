<?php
require_once __DIR__ . '/../../includes/bootstrap.php';

$id = (int) ($_GET['id'] ?? 0);

try {
    $consulta = banco()->prepare(
        'SELECT v.*, u.nome AS criador_nome, u.foto_perfil AS criador_foto,
                c.nome AS categoria_nome,
                (SELECT COUNT(*) FROM inscricao i WHERE i.id_canal = v.id_usuario) AS inscritos
         FROM video v
         JOIN usuario u ON u.id_usuario = v.id_usuario
         JOIN categoria c ON c.id_categoria = v.id_categoria
         WHERE v.id_video = ? AND v.status = "ativo"
         LIMIT 1'
    );
    $consulta->execute([$id]);
    $video = $consulta->fetch();

    if (!$video) {
        http_response_code(404);
        $tituloPagina = 'Vídeo não encontrado';
        require __DIR__ . '/../../includes/header.php';
        echo '<main class="container page-section"><div class="empty-state"><h1>Vídeo não disponível</h1><p>O conteúdo pode ter sido removido ou o endereço está incorreto.</p><a class="btn btn-primary" href="' .
            textoSeguro(endereco('paginas/inicio/home.php')) .
            '">Voltar para a Home</a></div></main>';
        require __DIR__ . '/../../includes/footer.php';
        exit();
    }

    $chaveVisualizacao = 'video_' . $id;
    $ultimaVisualizacao = (int) ($_SESSION['_views'][$chaveVisualizacao] ?? 0);
    if (time() - $ultimaVisualizacao >= 1800) {
        $consultaGravacao = banco()->prepare(
            'UPDATE video SET visualizacoes = visualizacoes + 1 WHERE id_video = ?'
        );
        $consultaGravacao->execute([$id]);
        $_SESSION['_views'][$chaveVisualizacao] = time();
        $video['visualizacoes'] = (int) $video['visualizacoes'] + 1;
    }

    if (estaLogado()) {
        $consultaGravacao = banco()->prepare(
            'INSERT INTO historico (id_usuario, id_video, data_assistido)
             VALUES (?, ?, CURRENT_TIMESTAMP)
             ON DUPLICATE KEY UPDATE data_assistido = CURRENT_TIMESTAMP'
        );
        $consultaGravacao->execute([(int) usuarioAtual()['id_usuario'], $id]);
    }

    $inscrito = false;
    if (estaLogado() && (int) usuarioAtual()['id_usuario'] !== (int) $video['id_usuario']) {
        $s = banco()->prepare(
            'SELECT id_inscricao FROM inscricao WHERE id_seguidor = ? AND id_canal = ? LIMIT 1'
        );
        $s->execute([(int) usuarioAtual()['id_usuario'], (int) $video['id_usuario']]);
        $inscrito = (bool) $s->fetch();
    }

    $consultaRelacionados = banco()->prepare(
        'SELECT v.*, u.nome AS criador_nome, c.nome AS categoria_nome
         FROM video v
         JOIN usuario u ON u.id_usuario = v.id_usuario
         JOIN categoria c ON c.id_categoria = v.id_categoria
         WHERE v.status = "ativo" AND v.id_video <> ?
         ORDER BY (v.id_categoria = ?) DESC, v.data_publicacao DESC
         LIMIT 8'
    );
    $consultaRelacionados->execute([$id, (int) $video['id_categoria']]);
    $relacionados = $consultaRelacionados->fetchAll();
} catch (Throwable $erro) {
    http_response_code(500);
    exit(textoSeguro($erro->getMessage()));
}

$tituloPagina = (string) $video['titulo'];
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="player-layout">
        <section class="video-main">
            <video class="video-player" controls playsinline preload="metadata" poster="<?= textoSeguro( endereco((string) $video['thumbnail']) ) ?>">
                <source src="<?= textoSeguro(endereco((string) $video['arquivo_video'])) ?>">
                Seu navegador não consegue reproduzir este vídeo.
            </video>

            <h1><?= textoSeguro((string) $video['titulo']) ?></h1>
            <div class="video-meta-line">
                <span><?= textoSeguro( formatarVisualizacoes((int) $video['visualizacoes']) ) ?> visualizações</span>
                <span aria-hidden="true">•</span>
                <span><?= textoSeguro(formatarData((string) $video['data_publicacao'])) ?></span>
                <span aria-hidden="true">•</span>
                <span><?= textoSeguro((string) $video['categoria_nome']) ?></span>
                <span aria-hidden="true">•</span>
                <span><?= textoSeguro(formatarDuracao((int) $video['duracao_segundos'])) ?></span>
            </div>

            <div class="channel-row">
                <?php if (!empty($video['criador_foto'])): ?>
                <img class="avatar-img avatar-lg" src="<?= textoSeguro( endereco((string) $video['criador_foto']) ) ?>" alt="">
                <?php else: ?>
                <span class="avatar avatar-lg" aria-hidden="true"><?= textoSeguro( iniciais((string) $video['criador_nome']) ) ?></span>
                <?php endif; ?>

                <div class="channel-row__info">
                    <a href="<?= textoSeguro( endereco('paginas/canal/perfil.php?id=' . (int) $video['id_usuario']) ) ?>"><strong><?= textoSeguro((string) $video['criador_nome']) ?></strong></a>
                    <span><?= (int) $video['inscritos'] ?> inscritos</span>
                </div>

                <?php if ( estaLogado() && (int) usuarioAtual()['id_usuario'] !== (int) $video['id_usuario'] ): ?>
                <form method="post" action="<?= textoSeguro(endereco('paginas/canal/inscricao.php')) ?>">
                    <?= campoToken() ?>
                    <input type="hidden" name="id_canal" value="<?= (int) $video['id_usuario'] ?>">
                    <input type="hidden" name="retorno" value="<?= textoSeguro('paginas/videos/video.php?id=' . $id) ?>">
                    <input type="hidden" name="acao" value="<?= $inscrito ? 'cancelar' : 'inscrever' ?>">
                    <button class="btn <?= $inscrito ? 'btn-ghost' : 'btn-primary' ?>" type="submit">
                        <?= $inscrito ? 'Inscrito ✓' : 'Inscrever-se' ?>
                    </button>
                </form>
                <?php elseif (!estaLogado()): ?>
                <a class="btn btn-primary" href="<?= textoSeguro( endereco('paginas/acesso/login.php') ) ?>">Entrar para se inscrever</a>
                <?php endif; ?>
            </div>

            <div class="card card-pad" style="margin-top:18px">
                <strong>Sobre este conteúdo</strong>
                <?php if (str_starts_with(basename((string) $video['arquivo_video']), 'demo_')): ?>
                <p class="small">Vídeo de demonstração · Material educativo original, sem narração. Os exemplos não representam dados de alunos reais.</p>
                <?php endif; ?>
                <p class="muted small" style="margin:8px 0 0">
                    Publicado em <?= textoSeguro( date('d/m/Y \à\s H:i', strtotime((string) $video['data_publicacao'])) ) ?> na categoria <?= textoSeguro((string) $video['categoria_nome']) ?>.
                    A EtecBox incentiva o uso de trabalhos como referência: ver, aprender, adaptar e criar.
                </p>
            </div>
        </section>

        <aside aria-labelledby="outros-videos-title">
            <div class="section-head">
                <div>
                    <h2 id="outros-videos-title" style="font-size:1.1rem">Outros vídeos</h2>
                </div>
            </div>
            <div class="sidebar-videos">
                <?php foreach ($relacionados as $item): ?>
                <article class="sidebar-video">
                    <a class="video-card__thumb" href="<?= textoSeguro( endereco('paginas/videos/video.php?id=' . (int) $item['id_video']) ) ?>">
                        <img src="<?= textoSeguro( endereco((string) $item['thumbnail']) ) ?>" alt="" loading="lazy">
                        <span class="duration-badge"><?= textoSeguro( formatarDuracao((int) $item['duracao_segundos']) ) ?></span>
                    </a>
                    <div>
                        <h3><a href="<?= textoSeguro( endereco('paginas/videos/video.php?id=' . (int) $item['id_video']) ) ?>"><?= textoSeguro((string) $item['titulo']) ?></a></h3>
                        <p><?= textoSeguro((string) $item['criador_nome']) ?></p>
                        <p><?= textoSeguro( formatarVisualizacoes((int) $item['visualizacoes']) ) ?> visualizações</p>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        </aside>
    </div>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
