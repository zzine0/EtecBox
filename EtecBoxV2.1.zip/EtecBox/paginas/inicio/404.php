<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
http_response_code(404);
$tituloPagina = 'Página não encontrada';
require __DIR__ . '/../../includes/header.php';
?>
<main class="container page-section">
    <div class="empty-state">
        <h1>Página não encontrada</h1>
        <p>O endereço informado não existe na EtecBox.</p>
        <a class="btn btn-primary" href="<?= textoSeguro(endereco('paginas/inicio/home.php')) ?>">Voltar para a Home</a>
    </div>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
