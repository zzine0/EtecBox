<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/video_card.php';

$pesquisa = '';
if (isset($_GET['q']) && is_string($_GET['q'])) {
    $pesquisa = limitarTexto(trim($_GET['q']), 120);
}

$categoriaId = max(0, (int) ($_GET['categoria'] ?? 0));
$pagina = max(1, min(10000, (int) ($_GET['pagina'] ?? 1)));
$porPagina = 24;
$ordem = 'recentes';
if (isset($_GET['ordem']) && $_GET['ordem'] == 'vistos') {
    $ordem = 'vistos';
}

$tituloPagina = 'Início';
if ($pesquisa != '') {
    $tituloPagina = 'Pesquisa: ' . $pesquisa;
}

function linkDaPesquisa($alteracoes = [])
{
    global $pesquisa, $categoriaId, $ordem;
    $parametros = ['q' => $pesquisa, 'categoria' => $categoriaId, 'ordem' => $ordem];
    foreach ($alteracoes as $chave => $valor) {
        $parametros[$chave] = $valor;
    }
    foreach ($parametros as $chave => $valor) {
        if ($valor === '' || $valor === 0) {
            unset($parametros[$chave]);
        }
    }
    return endereco('paginas/inicio/home.php?' . http_build_query($parametros));
}

try {
    $conexao = banco();
    $consultaCategorias = $conexao->query('SELECT id_categoria, nome FROM categoria ORDER BY id_categoria');
    $categorias = $consultaCategorias->fetchAll();
    $condicao = 'v.status = "ativo"';
    $parametros = [];

    if ($pesquisa != '') {
        $condicao .= ' AND (v.titulo LIKE ? OR u.nome LIKE ? OR c.nome LIKE ?)';
        $termo = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $pesquisa) . '%';
        $parametros[] = $termo;
        $parametros[] = $termo;
        $parametros[] = $termo;
    }
    if ($categoriaId > 0) {
        $condicao .= ' AND v.id_categoria = ?';
        $parametros[] = $categoriaId;
    }

    $tabelas =
        ' FROM video v
              JOIN usuario u ON u.id_usuario = v.id_usuario
              JOIN categoria c ON c.id_categoria = v.id_categoria
              WHERE ' . $condicao;
    $contagem = $conexao->prepare('SELECT COUNT(*)' . $tabelas);
    $contagem->execute($parametros);
    $total = (int) $contagem->fetchColumn();
    $paginas = max(1, (int) ceil($total / $porPagina));
    $pagina = min($pagina, $paginas);
    $inicio = ($pagina - 1) * $porPagina;

    $ordenacao = 'v.data_publicacao DESC, v.id_video DESC';
    if ($ordem == 'vistos') {
        $ordenacao = 'v.visualizacoes DESC, ' . $ordenacao;
    }

    $sql = 'SELECT v.*, u.nome AS criador_nome, u.foto_perfil AS criador_foto, c.nome AS categoria_nome';
    $sql .= $tabelas . ' ORDER BY ' . $ordenacao;
    $sql .= ' LIMIT ' . $porPagina . ' OFFSET ' . $inicio;
    $consulta = $conexao->prepare($sql);
    $consulta->execute($parametros);
    $videos = $consulta->fetchAll();
} catch (Throwable $erro) {
    $categorias = [];
    $videos = [];
    $total = 0;
    $paginas = 1;
    $erroBanco = true;
    http_response_code(503);
    error_log('EtecBox feed: ' . $erro->getMessage());
}
require __DIR__ . '/../../includes/header.php';
?>
<main class="container feed-page">
    <nav class="category-bar" aria-label="Filtrar por categoria">
        <a class="category-pill <?= $categoriaId === 0 ? 'is-active' : '' ?>" href="<?= textoSeguro( linkDaPesquisa(['categoria' => 0]) ) ?>" <?= $categoriaId === 0 ? 'aria-current="true"' : '' ?>>Tudo</a>
        <?php foreach ($categorias as $categoria): ?>
        <a class="category-pill <?= $categoriaId === (int) $categoria['id_categoria'] ? 'is-active' : '' ?>" href="<?= textoSeguro( linkDaPesquisa(['categoria' => (int) $categoria['id_categoria']]) ) ?>" <?= $categoriaId === (int) $categoria['id_categoria'] ? 'aria-current="true"' : '' ?>><?= textoSeguro( (string) $categoria['nome'] ) ?></a>
        <?php endforeach; ?>
    </nav>
    <?php if (isset($erroBanco)): ?>
    <?php if (ETECBOX_DOCKER): ?>
    <div class="empty-state">
        <h1>Não foi possível carregar os vídeos</h1>
        <p>O banco está indisponível. Tente novamente em instantes.</p><a class="btn btn-primary" href="<?= textoSeguro( endereco('instalacao/diagnostico.php') ) ?>">Verificar conexão</a>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <h1>Vamos preparar a EtecBox?</h1>
        <p>Conecte o banco de dados para carregar os vídeos.</p><a class="btn btn-primary" href="<?= textoSeguro( endereco('instalacao/setup.php') ) ?>">Configurar EtecBox</a>
    </div>
    <?php endif; ?>
    <?php else: ?>
    <div class="feed-toolbar">
        <div>
            <h1><?= $pesquisa !== '' ? 'Resultados para “' . textoSeguro($pesquisa) . '”' : 'Vídeos' ?></h1>
            <?php if ( $pesquisa !== '' ): ?>
            <p class="muted small"><?= $total ?> <?= $total === 1 ? 'resultado' : 'resultados' ?></p>
            <?php endif; ?>
        </div>
        <form method="get" class="sort-form"><input type="hidden" name="q" value="<?= textoSeguro( $pesquisa ) ?>"><input type="hidden" name="categoria" value="<?= $categoriaId ?>"><label for="ordem" class="sr-only">Ordenar vídeos</label><select name="ordem" id="ordem" data-auto-submit>
                <option value="recentes" <?= $ordem === 'recentes' ? 'selected' : '' ?>>Mais recentes</option>
                <option value="vistos" <?= $ordem === 'vistos' ? 'selected' : '' ?>>Mais vistos</option>
            </select><noscript><button type="submit">Ordenar</button></noscript></form>
    </div>
    <?php if ($videos): ?>
    <div class="video-grid">
        <?php foreach ($videos as $video) { mostrarVideo($video); } ?>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <h2><?= $pesquisa !== '' || $categoriaId > 0 ? 'Nenhum vídeo encontrado' : 'O primeiro vídeo pode ser o seu' ?></h2>
        <p><?= $pesquisa !== '' || $categoriaId > 0 ? 'Tente outro assunto ou veja todas as categorias.' : 'Publique um trabalho, uma apresentação ou algo que você aprendeu.' ?></p><a class="btn btn-ghost" href="<?= textoSeguro( endereco($pesquisa !== '' || $categoriaId > 0 ? 'paginas/inicio/home.php' : 'paginas/videos/upload.php') ) ?>"><?= $pesquisa !== '' || $categoriaId > 0 ? 'Ver todos os vídeos' : 'Enviar vídeo' ?></a>
    </div>
    <?php endif; ?>
    <?php if ($paginas > 1): ?>
    <nav class="pagination" aria-label="Páginas de vídeos">
        <?php if ( $pagina > 1 ): ?>
        <a class="btn btn-ghost" href="<?= textoSeguro( linkDaPesquisa(['pagina' => $pagina - 1]) ) ?>">Anterior</a>
        <?php endif; ?>
        <span>Página <?= $pagina ?> de <?= $paginas ?></span>
        <?php if ( $pagina < $paginas ): ?>
        <a class="btn btn-ghost" href="<?= textoSeguro( linkDaPesquisa(['pagina' => $pagina + 1]) ) ?>">Próxima</a>
        <?php endif; ?>
    </nav>
    <?php endif; ?>
    <?php endif; ?>
</main>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
