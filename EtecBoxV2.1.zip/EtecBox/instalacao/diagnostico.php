<?php
$verificacoes = [];
$verificacoes[] = ['PHP 8+', version_compare(PHP_VERSION, '8.0.0', '>='), PHP_VERSION];
$verificacoes[] = ['PDO', extension_loaded('pdo'), extension_loaded('pdo') ? 'habilitado' : 'ausente'];
$verificacoes[] = [
    'PDO MySQL',
    extension_loaded('pdo_mysql'),
    extension_loaded('pdo_mysql') ? 'habilitado' : 'ausente'
];
$verificacoes[] = [
    'Fileinfo',
    extension_loaded('fileinfo'),
    extension_loaded('fileinfo') ? 'habilitado' : 'ausente'
];
foreach (['uploads/videos', 'uploads/thumbnails', 'uploads/perfis'] as $dir) {
    $caminho = __DIR__ . '/../' . $dir;
    $ok = is_dir($caminho) && is_writable($caminho);
    $verificacoes[] = [$dir . ' gravável', $ok, $ok ? 'OK' : 'sem permissão de escrita'];
}
$mensagemBanco = 'não testado';
$bancoDisponivel = false;
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/conexao.php';
try {
    verificarTabelas(abrirConexao());
    $bancoDisponivel = true;
    $mensagemBanco = 'conexão, autenticação, banco e cinco tabelas disponíveis';
} catch (Throwable $erro) {
    $mensagemBanco = ETECBOX_DOCKER
        ? erroDoBanco($erro)
        : 'Confira host, porta, banco, usuário e senha em config/config.local.php e se o MySQL está iniciado.';
}
$verificacoes[] = ['Banco da EtecBox', $bancoDisponivel, $mensagemBanco];
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Diagnóstico EtecBox</title>
    <style>
        body {
            font-family: system-ui;
            background: #f8fafc;
            color: #1e3a5f;
            margin: 0
        }

        .wrap {
            max-width: 850px;
            margin: 40px auto;
            padding: 0 18px
        }

        .box {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 18px;
            padding: 22px
        }

        .row {
            display: grid;
            grid-template-columns: 1.2fr .8fr 2fr;
            gap: 12px;
            padding: 11px 0;
            border-bottom: 1px solid #e2e8f0
        }

        .ok {
            color: #15803d;
            font-weight: 800
        }

        .bad {
            color: #b91c1c;
            font-weight: 800
        }

        a {
            display: inline-block;
            margin-top: 18px;
            margin-right: 10px;
            background: #2563eb;
            color: #fff;
            padding: 10px 14px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 700
        }
    </style>
</head>
<body>
    <div class="wrap">
        <h1>Diagnóstico da EtecBox</h1>
        <p>Esta página verifica se o computador está pronto para executar a versão PHP + MySQL.</p>
        <div class="box">
            <?php foreach (
    $verificacoes
    as $verificacao
):

    $nome = $verificacao[0];
    $ok = $verificacao[1];
    $detalhe = $verificacao[2];
    ?>
            <div class="row"><b><?= htmlspecialchars($nome) ?></b><span class="<?= $ok ? 'ok' : 'bad' ?>"><?= $ok ? 'OK' : 'ATENÇÃO' ?></span><span><?= htmlspecialchars((string) $detalhe) ?></span></div>
            <?php
endforeach; ?>
        </div>
        <?php if ( !ETECBOX_DOCKER ): ?>
        <a href="setup.php">Abrir instalador</a>
        <?php endif; ?>
        <a href="../index.php">Abrir EtecBox</a>
    </div>
</body>
</html>
