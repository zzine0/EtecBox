<?php
$bloqueio = __DIR__ . '/../config/installed.lock';
$arquivoConfiguracao = __DIR__ . '/../config/config.local.php';
$mensagens = [];
$erros = [];

if (is_file($bloqueio)) {
    $instalado = true;
} else {
    $instalado = false;
}

function textoSeguroInstalacao($v)
{
    return htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

if (!$instalado && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $host = trim((string) ($_POST['db_host'] ?? '127.0.0.1'));
    $port = trim((string) ($_POST['db_port'] ?? '3306'));
    $nome = trim((string) ($_POST['db_name'] ?? 'etecbox'));
    $usuario = trim((string) ($_POST['db_user'] ?? 'root'));
    $pass = (string) ($_POST['db_pass'] ?? '');

    if (!preg_match('/^[A-Za-z0-9_]+$/', $nome)) {
        $erros[] = 'O nome do banco deve conter apenas letras, números e underscore.';
    } elseif (!extension_loaded('pdo_mysql')) {
        $erros[] = 'A extensão pdo_mysql não está habilitada no PHP.';
    } else {
        try {
            $servidor = new PDO("mysql:host={$host};port={$port};charset=utf8mb4", $usuario, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);
            $servidor->exec(
                "CREATE DATABASE IF NOT EXISTS `{$nome}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            );
            $conexao = new PDO(
                "mysql:host={$host};port={$port};dbname={$nome};charset=utf8mb4",
                $usuario,
                $pass,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );

            $sql = file_get_contents(__DIR__ . '/../database/schema_only.sql');
            if ($sql === false) {
                throw new RuntimeException('Não foi possível ler o schema do banco.');
            }
            foreach (preg_split('/;\s*(?:\r?\n|$)/', $sql) as $comando) {
                $comando = trim($comando);
                if ($comando !== '') {
                    $conexao->exec($comando);
                }
            }

            $seed = file_get_contents(__DIR__ . '/../database/seed.sql');
            if ($seed !== false) {
                foreach (preg_split('/;\s*(?:\r?\n|$)/', $seed) as $comando) {
                    $comando = trim($comando);
                    if ($comando !== '') {
                        $conexao->exec($comando);
                    }
                }
            }

            $config =
                "<?php\nreturn " .
                var_export(
                    [
                        'db_host' => $host,
                        'db_port' => $port,
                        'db_name' => $nome,
                        'db_user' => $usuario,
                        'db_pass' => $pass
                    ],
                    true
                ) .
                ";\n";
            file_put_contents($arquivoConfiguracao, $config);
            file_put_contents($bloqueio, date('c'));
            $instalado = true;
            $mensagens[] = 'EtecBox instalada com sucesso.';
        } catch (Throwable $erro) {
            $erros[] = 'Falha na instalação: ' . $erro->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Configurar EtecBox</title>
    <style>
        body {
            font-family: system-ui, -apple-system, sans-serif;
            background: #F8FAFC;
            color: #172033;
            margin: 0
        }

        main {
            width: min(720px, calc(100% - 30px));
            margin: 50px auto
        }

        .card {
            background: #fff;
            border: 1px solid #E2E8F0;
            border-radius: 20px;
            padding: 28px;
            box-shadow: 0 12px 36px rgba(30, 58, 95, .08)
        }

        h1 {
            color: #1E3A5F
        }

        .grid {
            display: grid;
            gap: 14px
        }

        .row {
            display: grid;
            gap: 6px
        }

        input {
            padding: 11px;
            border: 1px solid #CBD5E1;
            border-radius: 10px
        }

        .btn {
            display: inline-block;
            border: 0;
            background: #2563EB;
            color: white;
            padding: 11px 16px;
            border-radius: 10px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none
        }

        .ok {
            background: #DCFCE7;
            color: #166534;
            padding: 12px;
            border-radius: 10px
        }

        .err {
            background: #FEE2E2;
            color: #991B1B;
            padding: 12px;
            border-radius: 10px
        }

        .muted {
            color: #64748B
        }
    </style>
</head>
<body>
    <main>
        <div class="card">
            <h1>Configurar EtecBox</h1>
            <?php foreach ($mensagens as $m): ?>
            <p class="ok"><?= textoSeguroInstalacao($m) ?></p>
            <?php endforeach; ?>
            <?php foreach ($erros as $m): ?>
            <p class="err"><?= textoSeguroInstalacao($m) ?></p>
            <?php endforeach; ?>

            <?php if ($instalado): ?>
            <p>A instalação está concluída e o banco está pronto.</p>
            <p><strong>Contas de demonstração:</strong></p>
            <ul>
                <li>Administrador: <code>admin@etecbox.local</code> / <code>admin123</code></li>
                <li>Aluno: <code>aluno@etecbox.local</code> / <code>etecbox123</code></li>
                <li>Ana Souza: <code>ana@etecbox.local</code> / <code>etecbox123</code></li>
            </ul>
            <a class="btn" href="../index.php">Abrir a EtecBox</a>
            <p class="muted" style="margin-top:20px">Por segurança, setup.php foi bloqueado pelo arquivo <code>config/installed.lock</code>. Para reinstalar, apague esse arquivo manualmente.</p>
            <?php else: ?>
            <p class="muted">Use os dados do MySQL/MariaDB. No XAMPP local, normalmente é usuário <strong>root</strong> e senha vazia.</p>
            <form method="post" class="grid">
                <div class="row"><label>Host</label><input name="db_host" value="127.0.0.1" required></div>
                <div class="row"><label>Porta</label><input name="db_port" value="3306" required></div>
                <div class="row"><label>Nome do banco</label><input name="db_name" value="etecbox" required></div>
                <div class="row"><label>Usuário MySQL</label><input name="db_user" value="root" required></div>
                <div class="row"><label>Senha MySQL</label><input type="password" name="db_pass" value=""></div>
                <button class="btn" type="submit">Criar banco e instalar</button>
            </form>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
