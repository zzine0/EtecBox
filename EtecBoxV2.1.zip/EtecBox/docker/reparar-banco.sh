#!/usr/bin/env bash
set -euo pipefail

: "${MYSQL_DATABASE:?MYSQL_DATABASE não definido}"
: "${MYSQL_USER:?MYSQL_USER não definido}"
: "${MYSQL_PASSWORD:?MYSQL_PASSWORD não definido}"

if [[ ! "$MYSQL_DATABASE" =~ ^[A-Za-z0-9_]{1,64}$ || ! "$MYSQL_USER" =~ ^[A-Za-z0-9_]{1,32}$ || "$MYSQL_USER" == root ]]; then
    echo '[EtecBox] Nome de banco/usuário inválido para este reparo. Use letras, números e underscore; não use root como usuário da aplicação.' >&2
    exit 1
fi
case "${MYSQL_DATABASE,,}" in
    mysql|sys|information_schema|performance_schema)
        echo '[EtecBox] O reparo não pode usar um banco de sistema.' >&2
        exit 1 ;;
esac

root_password="${MYSQL_ROOT_PASSWORD-}"
mysql_root() {
    MYSQL_PWD="$root_password" mysql --protocol=socket --user=root --connect-timeout=5 --batch --skip-column-names --binary-mode=1 "$@"
}

if ! mysql_root --execute='SELECT 1' >/dev/null 2>&1; then
    if [[ ! -t 0 ]]; then
        echo '[EtecBox] Root não autenticou. Execute sem -T para informar a senha root já existente no volume.' >&2
        exit 1
    fi
    read -r -s -p 'Senha root atual do MySQL (não será exibida): ' root_password
    printf '\n'
    if ! mysql_root --execute='SELECT 1' >/dev/null 2>&1; then
        echo '[EtecBox] Não foi possível autenticar como root. Confira a senha atual e os logs do MySQL. Nenhuma alteração foi feita.' >&2
        exit 1
    fi
fi

password_sql="${MYSQL_PASSWORD//\'/\'\'}"
grant_database="${MYSQL_DATABASE//_/\\_}"
error_file="$(mktemp)"
trap 'rm -f "$error_file"; unset root_password password_sql' EXIT

printf '[EtecBox] Sincronizando a conta %s e o acesso ao banco %s.\n' "$MYSQL_USER" "$MYSQL_DATABASE"
if ! mysql_root >/dev/null 2>"$error_file" <<SQL
SET SESSION sql_mode = 'NO_BACKSLASH_ESCAPES';
CREATE DATABASE IF NOT EXISTS \`$MYSQL_DATABASE\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$MYSQL_USER'@'%' IDENTIFIED BY '$password_sql';
ALTER USER '$MYSQL_USER'@'%' IDENTIFIED BY '$password_sql';
GRANT ALL PRIVILEGES ON \`$grant_database\`.* TO '$MYSQL_USER'@'%';
SQL
then
    echo '[EtecBox] O reparo não terminou. Confira as permissões do root e a política de senhas do servidor. Tabelas e uploads não foram apagados; uma etapa anterior pode ter sido aplicada.' >&2
    exit 1
fi

if ! MYSQL_PWD="$MYSQL_PASSWORD" mysql --protocol=TCP --host=127.0.0.1 --port=3306 --user="$MYSQL_USER" --connect-timeout=3 --batch --skip-column-names --database="$MYSQL_DATABASE" --execute='SELECT 1' >/dev/null 2>&1; then
    echo '[EtecBox] Conta atualizada, mas a conexão TCP falhou. Verifique os logs e contas do mesmo usuário com hosts mais específicos.' >&2
    exit 1
fi

echo '[EtecBox] Acesso reparado. Execute: docker compose up -d --build'
echo '[EtecBox] Registros e uploads preservados. A senha root não foi alterada.'
