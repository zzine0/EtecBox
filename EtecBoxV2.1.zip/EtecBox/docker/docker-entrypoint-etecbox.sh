#!/bin/sh
set -eu

echo "[EtecBox] Verificando banco de dados..."
php /var/www/html/docker/docker-init.php

echo "[EtecBox] Iniciando Apache..."
exec apache2-foreground
