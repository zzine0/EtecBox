<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/conexao.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
try {
    verificarTabelas(abrirConexao());
    echo '{"status":"ok"}';
} catch (Throwable $erro) {
    http_response_code(503);
    echo '{"status":"unavailable"}';
    exit(1);
}
