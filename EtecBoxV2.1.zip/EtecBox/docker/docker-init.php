<?php

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit();
}

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/conexao.php';

$somenteVerificar = in_array('--check', $argv, true);
$tempoEspera = max(1, min(600, (int) (getenv('ETECBOX_DB_WAIT_SECONDS') ?: 180)));
$limiteEspera = microtime(true) + $tempoEspera;
$tentativa = 0;

function executarArquivoSql($conexao, $caminho)
{
    $sql = file_get_contents($caminho);
    if ($sql === false) {
        throw new RuntimeException('Não foi possível ler o arquivo SQL necessário.');
    }

    $sql = preg_replace('/^\s*--[^\r\n]*/m', '', $sql) ?? $sql;
    foreach (preg_split('/;\s*(?:\r?\n|$)/', $sql) ?: [] as $comando) {
        if (trim($comando) !== '') {
            $conexao->exec($comando);
        }
    }
}

while (true) {
    try {
        try {
            $conexao = abrirConexao();
        } catch (PDOException $erro) {
            if ($somenteVerificar || (int) ($erro->errorInfo[1] ?? 0) !== 1049) {
                throw $erro;
            }

            $servidor = abrirConexao(false);
            $nomeBanco = '`' . str_replace('`', '``', DB_NAME) . '`';
            $servidor->exec(
                'CREATE DATABASE IF NOT EXISTS ' .
                    $nomeBanco .
                    ' CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci'
            );
            $servidor = null;
            $conexao = abrirConexao();
        }
        break;
    } catch (Throwable $erro) {
        $codigo = $erro instanceof PDOException ? (int) ($erro->errorInfo[1] ?? 0) : 0;
        $falhaTemporaria = in_array($codigo, [1040, 2002, 2003, 2005, 2006, 2013], true);
        if ($somenteVerificar || !$falhaTemporaria || microtime(true) >= $limiteEspera) {
            fwrite(STDERR, '[EtecBox] ' . erroDoBanco($erro) . "\n");
            exit(1);
        }
        if ($tentativa++ % 5 === 0) {
            fwrite(STDERR, "[EtecBox] Aguardando conexão TCP com MySQL (limite {$tempoEspera}s)...\n");
        }
        usleep((int) (min(2.0, max(0.0, $limiteEspera - microtime(true))) * 1000000));
    }
}

if ($somenteVerificar) {
    try {
        verificarTabelas($conexao);
        fwrite(STDOUT, "[EtecBox] Conexão, autenticação, banco e tabelas: OK.\n");
        exit(0);
    } catch (Throwable $erro) {
        fwrite(STDERR, '[EtecBox] ' . erroDoBanco($erro) . "\n");
        exit(1);
    }
}

$nomeBloqueio = 'etecbox:init:' . substr(hash('sha256', DB_NAME), 0, 32);
$bloqueado = false;
$status = 0;
try {
    $bloqueio = $conexao->prepare('SELECT GET_LOCK(?, 30)');
    $bloqueio->execute([$nomeBloqueio]);
    if ((int) $bloqueio->fetchColumn() !== 1) {
        throw new RuntimeException('Outra inicialização está em andamento; tente novamente.');
    }
    $bloqueado = true;

    executarArquivoSql($conexao, __DIR__ . '/../database/schema_only.sql');
    verificarTabelas($conexao);
    $vazio = true;
    foreach (['usuario', 'categoria', 'video', 'inscricao', 'historico'] as $tabela) {
        if ($conexao->query('SELECT 1 FROM `' . $tabela . '` LIMIT 1')->fetchColumn() !== false) {
            $vazio = false;
            break;
        }
    }
    if ($vazio) {
        $conexao->beginTransaction();
        executarArquivoSql($conexao, __DIR__ . '/../database/seed.sql');
        $conexao->commit();
        fwrite(STDOUT, "[EtecBox] Banco vazio: dados de demonstração instalados.\n");
    } else {
        fwrite(STDOUT, "[EtecBox] Banco existente: registros preservados, sem reimportar demonstrações.\n");
    }
    fwrite(STDOUT, "[EtecBox] Banco pronto.\n");
} catch (Throwable $erro) {
    if ($conexao->inTransaction()) {
        $conexao->rollBack();
    }
    $detalhe = $erro instanceof PDOException ? erroDoBanco($erro) : $erro->getMessage();
    fwrite(STDERR, '[EtecBox] Falha na inicialização: ' . $detalhe . "\n");
    $status = 1;
} finally {
    if ($bloqueado) {
        try {
            $liberar = $conexao->prepare('SELECT RELEASE_LOCK(?)');
            $liberar->execute([$nomeBloqueio]);
        } catch (Throwable $ignorado) {
        }
    }
}
exit($status);
