<?php
function mostrarVideo($video)
{
    $capa = (string) ($video['thumbnail'] ?? '');
    $titulo = (string) ($video['titulo'] ?? 'Vídeo');
    $criador = (string) ($video['criador_nome'] ?? 'Usuário');
    $criadorId = (int) ($video['id_usuario'] ?? 0);
    $id = (int) ($video['id_video'] ?? 0);
    $duracao = (int) ($video['duracao_segundos'] ?? 0);
    $visualizacoes = (int) ($video['visualizacoes'] ?? 0);
    $data = (string) ($video['data_publicacao'] ?? '');
    $categoria = (string) ($video['categoria_nome'] ?? '');
    ?>
<article class="video-card">
    <a class="video-card__thumb" href="<?= textoSeguro( endereco('paginas/videos/video.php?id=' . $id) ) ?>" aria-label="Assistir <?= textoSeguro($titulo) ?>">
        <?php if ($capa !== ''): ?>
        <img src="<?= textoSeguro(endereco($capa)) ?>" alt="" loading="lazy">
        <?php else: ?>
        <div class="thumb-placeholder" aria-hidden="true"><span>▶</span></div>
        <?php endif; ?>
        <span class="duration-badge"><?= textoSeguro(formatarDuracao($duracao)) ?></span>
    </a>
    <div class="video-card__body">
        <a class="avatar-link" href="<?= textoSeguro( endereco('paginas/canal/perfil.php?id=' . $criadorId) ) ?>" aria-label="Canal de <?= textoSeguro($criador) ?>"><?= mostrarAvatar($video['criador_foto'] ?? null, $criador) ?></a>
        <div class="video-card__info">
            <h3><a href="<?= textoSeguro( endereco('paginas/videos/video.php?id=' . $id) ) ?>"><?= textoSeguro($titulo) ?></a></h3>
            <a class="creator-link" href="<?= textoSeguro( endereco('paginas/canal/perfil.php?id=' . $criadorId) ) ?>"><?= textoSeguro($criador) ?></a>
            <p class="meta-line">
                <?= textoSeguro(formatarVisualizacoes($visualizacoes)) ?> visualizações
                <span aria-hidden="true">•</span>
                <?= textoSeguro(formatarData($data)) ?>
            </p>
            <?php if (str_starts_with(basename((string) ($video['arquivo_video'] ?? '')), 'demo_')): ?>
            <span class="demo-label">Demonstração</span>
            <?php endif; ?>
        </div>
    </div>
</article>
<?php
}
