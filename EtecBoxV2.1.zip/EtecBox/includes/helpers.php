<?php

function textoSeguro($texto)
{
    return htmlspecialchars($texto ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function limitarTexto($texto, $limite)
{
    if (function_exists('mb_substr')) {
        return mb_substr($texto, 0, $limite);
    }
    return substr($texto, 0, $limite);
}

function mostrarAvatar($foto, $nome, $tamanho = 'sm')
{
    if (!in_array($tamanho, ['sm', 'lg', 'xl'])) {
        $tamanho = 'sm';
    }

    $pixels = 36;
    if ($tamanho == 'lg') {
        $pixels = 44;
    } elseif ($tamanho == 'xl') {
        $pixels = 120;
    }

    if ($foto) {
        return '<img class="avatar-img avatar-' .
            $tamanho .
            '" src="' .
            textoSeguro(endereco($foto)) .
            '" alt="" width="' .
            $pixels .
            '" height="' .
            $pixels .
            '" loading="lazy">';
    }
    return '<span class="avatar avatar-' .
        $tamanho .
        '" aria-hidden="true">' .
        textoSeguro(iniciais($nome)) .
        '</span>';
}

function pastaDoSite()
{
    $arquivo = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $pasta = rtrim(dirname($arquivo), '/');
    $pastasInternas = [
        '/paginas/inicio', '/paginas/acesso', '/paginas/conta',
        '/paginas/videos', '/paginas/canal', '/paginas/historico',
        '/paginas/informacoes', '/paginas/administracao', '/instalacao', '/docker'
    ];

    foreach ($pastasInternas as $interna) {
        if (str_ends_with($pasta, $interna)) {
            $pasta = substr($pasta, 0, -strlen($interna));
            break;
        }
    }
    if ($pasta == '.' || $pasta == '/') {
        return '';
    }
    return $pasta;
}

function endereco($caminho = '')
{
    $caminho = ltrim($caminho, '/');
    if ($caminho == '') {
        return pastaDoSite();
    }
    return pastaDoSite() . '/' . $caminho;
}

function redirecionar($caminho)
{
    $caminho = str_replace('\\', '/', trim($caminho));
    if ($caminho == '' || str_contains($caminho, '://') || str_starts_with($caminho, '//')) {
        $caminho = 'paginas/inicio/home.php';
    }
    header('Location: ' . endereco($caminho));
    exit();
}

function adicionarMensagem($tipo, $texto)
{
    $_SESSION['_flash'][] = ['type' => $tipo, 'message' => $texto];
}

function lerMensagens()
{
    $mensagens = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    if (!is_array($mensagens)) {
        return [];
    }
    return $mensagens;
}

function tokenFormulario()
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function campoToken()
{
    return '<input type="hidden" name="_csrf" value="' . textoSeguro(tokenFormulario()) . '">';
}

function verificarFormulario()
{
    $recebido = $_POST['_csrf'] ?? '';
    $salvo = $_SESSION['_csrf'] ?? '';

    if (!is_string($recebido) || !is_string($salvo) || $salvo == '' || !hash_equals($salvo, $recebido)) {
        http_response_code(419);
        exit('A sessão do formulário expirou. Volte à página anterior e tente novamente.');
    }
}

function formularioEnviado()
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') == 'POST';
}

function formatarDuracao($segundos)
{
    $segundos = max(0, (int) $segundos);
    $horas = intdiv($segundos, 3600);
    $minutos = intdiv($segundos % 3600, 60);
    $restante = $segundos % 60;

    if ($horas > 0) {
        return sprintf('%d:%02d:%02d', $horas, $minutos, $restante);
    }
    return sprintf('%d:%02d', $minutos, $restante);
}

function formatarVisualizacoes($quantidade)
{
    if ($quantidade >= 1000000) {
        return number_format($quantidade / 1000000, 1, ',', '.') . ' mi';
    }
    if ($quantidade >= 1000) {
        return number_format($quantidade / 1000, 1, ',', '.') . ' mil';
    }
    return (string) $quantidade;
}

function formatarData($data)
{
    $instante = strtotime($data);
    if ($instante === false) {
        return $data;
    }

    $diferenca = time() - $instante;
    if ($diferenca < 60) {
        return 'agora';
    }
    if ($diferenca < 3600) {
        $quantidade = intdiv($diferenca, 60);
        $unidade = 'minuto';
    } elseif ($diferenca < 86400) {
        $quantidade = intdiv($diferenca, 3600);
        $unidade = 'hora';
    } elseif ($diferenca < 604800) {
        $quantidade = intdiv($diferenca, 86400);
        $unidade = 'dia';
    } else {
        return date('d/m/Y', $instante);
    }
    if ($quantidade > 1) {
        $unidade .= 's';
    }
    return 'há ' . $quantidade . ' ' . $unidade;
}

function iniciais($nome)
{
    $palavras = preg_split('/\s+/u', trim($nome));
    if ($palavras === false) {
        $palavras = [];
    }
    $letras = '';
    $quantidade = 0;

    foreach ($palavras as $palavra) {
        if (preg_match('/[\p{L}\p{N}]/u', $palavra, $resultado)) {
            $letra = $resultado[0];
            if (function_exists('mb_strtoupper')) {
                $letra = mb_strtoupper($letra);
            } else {
                $letra = strtoupper($letra);
            }
            $letras .= $letra;
            $quantidade++;
        }
        if ($quantidade == 2) {
            break;
        }
    }
    if ($letras == '') {
        return 'EB';
    }
    return $letras;
}

function erroDeUpload($codigo)
{
    switch ($codigo) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return 'O arquivo excede o limite permitido.';
        case UPLOAD_ERR_PARTIAL:
            return 'O envio do arquivo foi interrompido.';
        case UPLOAD_ERR_NO_FILE:
            return 'Nenhum arquivo foi enviado.';
        case UPLOAD_ERR_NO_TMP_DIR:
            return 'A pasta temporária do servidor não está disponível.';
        case UPLOAD_ERR_CANT_WRITE:
            return 'O servidor não conseguiu salvar o arquivo.';
        case UPLOAD_ERR_EXTENSION:
            return 'O envio foi bloqueado por uma extensão do servidor.';
        default:
            return 'Falha desconhecida no upload.';
    }
}

function salvarArquivo($arquivo, $pasta, $formatos, $limite, $prefixo)
{
    $erro = $arquivo['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($erro != UPLOAD_ERR_OK) {
        throw new RuntimeException(erroDeUpload($erro));
    }
    if ($arquivo['size'] <= 0 || $arquivo['size'] > $limite) {
        throw new RuntimeException('O arquivo está vazio ou excede o limite permitido.');
    }

    $temporario = $arquivo['tmp_name'];
    if (!is_uploaded_file($temporario)) {
        throw new RuntimeException('Arquivo de upload inválido.');
    }

    $informacoes = new finfo(FILEINFO_MIME_TYPE);
    $formato = $informacoes->file($temporario);
    if (!isset($formatos[$formato])) {
        throw new RuntimeException('Formato não aceito: ' . $formato);
    }
    if (!is_dir($pasta)) {
        if (!mkdir($pasta, 0775, true) && !is_dir($pasta)) {
            throw new RuntimeException('Não foi possível preparar a pasta de upload.');
        }
    }

    $nome = $prefixo . '_' . bin2hex(random_bytes(12)) . '.' . $formatos[$formato];
    $destino = rtrim($pasta, '/') . '/' . $nome;
    if (!move_uploaded_file($temporario, $destino)) {
        throw new RuntimeException('Não foi possível salvar o arquivo enviado.');
    }
    return $nome;
}

function corrigirOrientacao($imagem, $caminho, $formato)
{
    if (!function_exists('exif_read_data') || $formato != 'image/jpeg') {
        return $imagem;
    }

    $dados = @exif_read_data($caminho);
    $orientacao = $dados['Orientation'] ?? 1;
    if (in_array($orientacao, [2, 4, 5, 7])) {
        imageflip($imagem, IMG_FLIP_HORIZONTAL);
    }

    $angulo = 0;
    if ($orientacao == 3 || $orientacao == 4) {
        $angulo = 180;
    } elseif ($orientacao == 5 || $orientacao == 6) {
        $angulo = -90;
    } elseif ($orientacao == 7 || $orientacao == 8) {
        $angulo = 90;
    }

    if ($angulo != 0) {
        $girada = imagerotate($imagem, $angulo, 0);
        if ($girada) {
            imagedestroy($imagem);
            $imagem = $girada;
        }
    }
    return $imagem;
}

function salvarFotoPerfil($arquivo, $pasta)
{
    $erro = $arquivo['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($erro != UPLOAD_ERR_OK) {
        throw new RuntimeException(erroDeUpload($erro));
    }
    if (!is_uploaded_file($arquivo['tmp_name'])) {
        throw new RuntimeException('Arquivo de upload inválido.');
    }

    $tamanho = @getimagesize($arquivo['tmp_name']);
    if (!$tamanho || $tamanho[0] < 1 || $tamanho[1] < 1 || $tamanho[0] * $tamanho[1] > 24000000) {
        throw new RuntimeException('Escolha uma imagem válida com até 24 megapixels.');
    }

    $formatos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $nome = salvarArquivo($arquivo, $pasta, $formatos, MAX_IMAGE_BYTES, 'perfil');
    $caminho = $pasta . '/' . $nome;
    if (!function_exists('imagecreatefromstring')) {
        return $nome;
    }

    $imagem = @imagecreatefromstring(file_get_contents($caminho));
    if (!$imagem) {
        apagarArquivo($caminho);
        throw new RuntimeException('Não foi possível processar a foto.');
    }
    $imagem = corrigirOrientacao($imagem, $caminho, $tamanho['mime']);

    $largura = imagesx($imagem);
    $altura = imagesy($imagem);
    $lado = min($largura, $altura);
    $inicioX = (int) (($largura - $lado) / 2);
    $inicioY = (int) (($altura - $lado) / 2);
    $foto = imagecreatetruecolor(512, 512);
    $branco = imagecolorallocate($foto, 255, 255, 255);
    imagefill($foto, 0, 0, $branco);
    imagecopyresampled($foto, $imagem, 0, 0, $inicioX, $inicioY, 512, 512, $lado, $lado);

    $nomeFinal = 'perfil_' . bin2hex(random_bytes(12)) . '.jpg';
    $salvou = imagejpeg($foto, $pasta . '/' . $nomeFinal, 88);
    imagedestroy($imagem);
    imagedestroy($foto);
    apagarArquivo($caminho);

    if (!$salvou) {
        apagarArquivo($pasta . '/' . $nomeFinal);
        throw new RuntimeException('Não foi possível salvar a foto.');
    }
    return $nomeFinal;
}

function duracaoDoVideo($caminho, $duracaoInformada = 0)
{
    $programas = ['ffprobe', '/usr/bin/ffprobe', '/usr/local/bin/ffprobe'];
    if (function_exists('shell_exec')) {
        foreach ($programas as $programa) {
            $comando = escapeshellcmd($programa);
            $comando .= ' -v error -show_entries format=duration';
            $comando .= ' -of default=noprint_wrappers=1:nokey=1 ';
            $comando .= escapeshellarg($caminho) . ' 2>&1';
            $resultado = @shell_exec($comando);
            if (is_string($resultado) && is_numeric(trim($resultado))) {
                return max(0, (int) round((float) $resultado));
            }
        }
    }
    return max(0, min($duracaoInformada, 12 * 3600));
}

function apagarArquivo($caminho)
{
    if ($caminho && is_file($caminho)) {
        @unlink($caminho);
    }
}
