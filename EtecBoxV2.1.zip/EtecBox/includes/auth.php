<?php
$usuarioLogado = null;

if (!empty($_SESSION['user_id'])) {
    try {
        $consulta = banco()->prepare(
            'SELECT id_usuario, nome, email, foto_perfil, data_criacao, tema, tipo
             FROM usuario WHERE id_usuario = ? LIMIT 1'
        );
        $consulta->execute([$_SESSION['user_id']]);
        $registro = $consulta->fetch();
        if ($registro) {
            $usuarioLogado = $registro;
        } else {
            unset($_SESSION['user_id']);
        }
    } catch (Throwable $erro) {
        $usuarioLogado = null;
    }
}

function usuarioAtual()
{
    global $usuarioLogado;
    return $usuarioLogado;
}

function estaLogado()
{
    return usuarioAtual() !== null;
}

function ehAdministrador()
{
    return (usuarioAtual()['tipo'] ?? '') === 'admin';
}

function exigirLogin()
{
    if (!estaLogado()) {
        adicionarMensagem('info', 'Entre na sua conta para continuar.');
        redirecionar('paginas/acesso/login.php');
    }
}

function exigirAdministrador()
{
    if (!estaLogado()) {
        adicionarMensagem('info', 'Entre na sua conta para continuar.');
        redirecionar('paginas/acesso/login.php');
    }
    if (!ehAdministrador()) {
        http_response_code(403);
        $tituloPagina = 'Acesso negado';
        require __DIR__ . '/header.php';
        echo '<main class="container page-section"><div class="empty-state"><h1>Acesso negado</h1><p>Esta área é exclusiva para administradores.</p><a class="btn btn-primary" href="' .
            textoSeguro(endereco('paginas/inicio/home.php')) .
            '">Voltar para a Home</a></div></main>';
        require __DIR__ . '/footer.php';
        exit();
    }
}
