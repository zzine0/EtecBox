<?php
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/icons.php';
$usuario = usuarioAtual();
$tituloPagina = $tituloPagina ?? APP_NAME;
$temaPagina = $usuario['tema'] ?? 'claro';
$mensagens = lerMensagens();
$paginaAtual = substr($_SERVER['SCRIPT_NAME'] ?? '', strlen(pastaDoSite()) + 1);
$paginaAdmin = str_contains(str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''), '/paginas/administracao/');
$textoPesquisa = is_string($_GET['q'] ?? null) ? limitarTexto(trim($_GET['q']), 120) : '';
function linkDoMenu($caminho, $rotulo, $simbolo, $ativo = false)
{
    $classe = 'side-link';
    $paginaSelecionada = '';
    if ($ativo) {
        $classe .= ' is-active';
        $paginaSelecionada = ' aria-current="page"';
    }
    echo '<a class="' .
        $classe .
        '" href="' .
        textoSeguro(endereco($caminho)) .
        '"' .
        $paginaSelecionada .
        '>';
    echo icone($simbolo);
    echo '<span>' . textoSeguro($rotulo) . '</span></a>';
}
?>
<!doctype html>
<html lang="pt-BR" data-theme="<?= textoSeguro($temaPagina) ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark">
    <meta name="theme-color" content="<?= $temaPagina === 'escuro' ? '#0f0f0f' : '#ffffff' ?>">
    <meta name="description" content="Trabalhos, apresentações e projetos da comunidade escolar. Assista, aprenda e compartilhe o que você criou na EtecBox.">
    <title><?= textoSeguro($tituloPagina) ?> — <?= textoSeguro(APP_NAME) ?></title>
    <link rel="icon" href="<?= textoSeguro(endereco('assets/img/logo.svg')) ?>" type="image/svg+xml">
    <link rel="stylesheet" href="<?= textoSeguro(endereco('assets/css/style.css?v=3')) ?>">
    <script src="<?= textoSeguro(endereco('assets/js/app.js?v=3')) ?>" defer></script>
</head>
<body>
    <a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
    <header class="site-header">
        <div class="header-inner">
            <div class="header-brand">
                <button class="icon-button nav-toggle" type="button" data-nav-toggle aria-expanded="false" aria-controls="main-nav" aria-label="Abrir menu"><?= icone( 'menu' ) ?></button>
                <a class="brand" href="<?= textoSeguro( endereco('paginas/inicio/home.php') ) ?>" aria-label="EtecBox — início"><img src="<?= textoSeguro( endereco('assets/img/logo.svg') ) ?>" alt="" width="34" height="34"><span>Etec<span class="brand-box">Box</span></span></a>
            </div>
            <form class="search-form" action="<?= textoSeguro(endereco('paginas/inicio/home.php')) ?>" method="get" role="search">
                <label class="sr-only" for="global-search">Pesquisar vídeos</label><input id="global-search" name="q" type="search" placeholder="Pesquisar" maxlength="120" value="<?= textoSeguro( $textoPesquisa ) ?>" autocomplete="off"><button type="submit" aria-label="Pesquisar"><?= icone('search') ?></button>
            </form>
            <div class="header-actions">
                <?php if ($usuario): ?>
                <a class="btn btn-ghost header-upload" href="<?= textoSeguro(endereco('paginas/videos/upload.php')) ?>"><?= icone( 'upload' ) ?><span>Enviar</span></a>
                <a class="profile-chip" href="<?= textoSeguro( endereco('paginas/canal/perfil.php?id=' . (int) $usuario['id_usuario']) ) ?>" aria-label="Meu perfil: <?= textoSeguro((string) $usuario['nome']) ?>"><?= mostrarAvatar( $usuario['foto_perfil'] ?? null, (string) $usuario['nome'], 'sm' ) ?></a>
                <?php else: ?>
                <a class="btn btn-signin" href="<?= textoSeguro(endereco('paginas/acesso/login.php')) ?>"><?= icone( 'user' ) ?><span>Entrar</span></a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <button class="nav-scrim" data-nav-close type="button" tabindex="-1" aria-label="Fechar menu" hidden></button>
    <aside class="site-sidebar" id="main-nav" data-nav aria-label="Menu lateral" tabindex="-1">
        <nav aria-label="Navegação principal">
            <div class="nav-group">
                <?php linkDoMenu('paginas/inicio/home.php', 'Início', 'home', $paginaAtual === 'paginas/inicio/home.php' && !$paginaAdmin); ?>
                <?php linkDoMenu('paginas/historico/historico.php', 'Histórico', 'history', $paginaAtual === 'paginas/historico/historico.php'); ?>
                <?php linkDoMenu( 'paginas/canal/meus_videos.php', 'Meus vídeos', 'play', in_array($paginaAtual, ['paginas/canal/meus_videos.php', 'paginas/videos/editar_video.php'], true) ); ?>
            </div>
            <div class="nav-group">
                <p class="nav-heading">Você</p>
                <?php linkDoMenu( $usuario ? 'paginas/canal/perfil.php?id=' . (int) $usuario['id_usuario'] : 'paginas/acesso/login.php', 'Meu canal', 'user', $paginaAtual === 'paginas/canal/perfil.php' && $usuario && (int) ($_GET['id'] ?? 0) === (int) $usuario['id_usuario'] ); ?>
                <?php linkDoMenu('paginas/videos/upload.php', 'Enviar vídeo', 'upload', $paginaAtual === 'paginas/videos/upload.php'); ?>
                <?php linkDoMenu( 'paginas/conta/configuracoes.php', 'Configurações', 'settings', $paginaAtual === 'paginas/conta/configuracoes.php' ); ?>
                <?php if (ehAdministrador()) { linkDoMenu('paginas/administracao/index.php', 'Administração', 'shield', $paginaAdmin); } ?>
            </div>
            <div class="nav-group">
                <?php linkDoMenu('paginas/informacoes/sobre.php', 'Sobre a EtecBox', 'info', $paginaAtual === 'paginas/informacoes/sobre.php'); ?>
                <?php linkDoMenu('paginas/informacoes/creditos.php', 'Créditos', 'credits', $paginaAtual === 'paginas/informacoes/creditos.php'); ?>
            </div>
            <?php if ( !$usuario ): ?>
            <div class="sidebar-signin">
                <p>Entre para publicar vídeos e acompanhar seus canais.</p><a class="btn btn-signin btn-sm" href="<?= textoSeguro( endereco('paginas/acesso/cadastro.php') ) ?>">Criar conta</a>
            </div>
            <?php endif; ?>
            <p class="sidebar-foot">EtecBox · Projeto escolar<br>ETEC Jardim Ângela · 2026</p>
        </nav>
    </aside>
    <div class="app-content" id="conteudo" tabindex="-1">
        <?php if ($mensagens): ?>
        <div class="flash-stack" aria-live="polite" aria-atomic="true">
            <?php foreach ($mensagens as $mensagem): ?>
            <div class="flash flash-<?= textoSeguro( (string) $mensagem['type'] ) ?>"><span><?= textoSeguro( (string) $mensagem['message'] ) ?></span><button type="button" class="flash-close" data-flash-close aria-label="Fechar mensagem"><?= icone( 'close' ) ?></button></div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
