<footer class="site-footer">
    <div class="container footer-inner"><span>EtecBox · 2026</span>
        <nav aria-label="Links do rodapé"><a href="<?= textoSeguro( endereco('paginas/informacoes/sobre.php') ) ?>">Sobre</a><a href="<?= textoSeguro(endereco('paginas/informacoes/creditos.php')) ?>">Créditos</a></nav>
    </div>
</footer>
</div>
</body>
</html>
