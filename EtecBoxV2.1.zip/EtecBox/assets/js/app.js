const botaoMenu = document.querySelector('[data-nav-toggle]');
const menu = document.querySelector('[data-nav]');
const fundoMenu = document.querySelector('[data-nav-close]');
const conteudo = document.querySelector('.app-content');
const telaPequena = window.matchMedia('(max-width: 959px)');

function fecharMenu() {
    if (menu) {
        menu.classList.remove('is-open');
    }
    document.body.classList.remove('menu-open');
    if (fundoMenu) {
        fundoMenu.hidden = true;
    }
    if (conteudo) {
        conteudo.inert = false;
    }
    if (botaoMenu) {
        const aberto = !telaPequena.matches && !document.body.classList.contains('nav-collapsed');
        botaoMenu.setAttribute('aria-expanded', String(aberto));
        if (telaPequena.matches) {
            botaoMenu.setAttribute('aria-label', 'Abrir menu');
        } else {
            botaoMenu.setAttribute('aria-label', 'Alternar menu');
        }
    }
}

function alternarMenu() {
    if (!telaPequena.matches) {
        document.body.classList.toggle('nav-collapsed');
        fecharMenu();
        return;
    }
    if (menu.classList.contains('is-open')) {
        fecharMenu();
        return;
    }

    menu.classList.add('is-open');
    document.body.classList.add('menu-open');
    botaoMenu.setAttribute('aria-expanded', 'true');
    botaoMenu.setAttribute('aria-label', 'Fechar menu');
    if (fundoMenu) {
        fundoMenu.hidden = false;
    }
    if (conteudo) {
        conteudo.inert = true;
    }
    const primeiroLink = menu.querySelector('a');
    if (primeiroLink) {
        primeiroLink.focus();
    }
}

function controlarTeclado(evento) {
    if (!telaPequena.matches || !menu.classList.contains('is-open')) {
        return;
    }
    if (evento.key === 'Escape') {
        fecharMenu();
        botaoMenu.focus();
    }
    if (evento.key === 'Tab') {
        const itens = [botaoMenu];
        const links = menu.querySelectorAll('a[href], button');
        for (let i = 0; i < links.length; i++) {
            itens.push(links[i]);
        }
        const atual = itens.indexOf(document.activeElement);
        const ultimo = itens.length - 1;
        if (evento.shiftKey && atual <= 0) {
            evento.preventDefault();
            itens[ultimo].focus();
        } else if (!evento.shiftKey && (atual === ultimo || atual < 0)) {
            evento.preventDefault();
            itens[0].focus();
        }
    }
}

if (botaoMenu && menu) {
    fecharMenu();
    botaoMenu.addEventListener('click', alternarMenu);
    document.addEventListener('keydown', controlarTeclado);
    telaPequena.addEventListener('change', fecharMenu);
    if (fundoMenu) {
        fundoMenu.addEventListener('click', function () {
            fecharMenu();
            botaoMenu.focus();
        });
    }
}

const seletores = document.querySelectorAll('[data-auto-submit]');
for (let i = 0; i < seletores.length; i++) {
    seletores[i].addEventListener('change', function () {
        if (this.form) {
            this.form.requestSubmit();
        }
    });
}

function mudarTema() {
    document.documentElement.dataset.theme = this.value;
    const aviso = document.querySelector('[data-theme-status]');
    const corNavegador = document.querySelector('meta[name="theme-color"]');
    if (aviso) {
        aviso.textContent = 'Prévia ativada. Salve para usar este tema nos próximos acessos.';
    }
    if (corNavegador) {
        if (this.value === 'escuro') {
            corNavegador.setAttribute('content', '#0f0f0f');
        } else {
            corNavegador.setAttribute('content', '#ffffff');
        }
    }
}

const temas = document.querySelectorAll('[data-theme-choice]');
for (let i = 0; i < temas.length; i++) {
    temas[i].addEventListener('change', mudarTema);
}

const campoFoto = document.querySelector('#foto_perfil');
const previaFoto = document.querySelector('[data-photo-preview]');
let fotoOriginal = '';
if (campoFoto && previaFoto) {
    fotoOriginal = previaFoto.innerHTML;
    campoFoto.addEventListener('change', mostrarPreviaFoto);
}

function mostrarPreviaFoto() {
    const arquivo = campoFoto.files[0];
    campoFoto.setCustomValidity('');
    if (!arquivo) {
        previaFoto.innerHTML = fotoOriginal;
        return;
    }

    const formatos = ['image/jpeg', 'image/png', 'image/webp'];
    if (formatos.indexOf(arquivo.type) === -1 || arquivo.size > 5 * 1024 * 1024) {
        campoFoto.setCustomValidity('Escolha uma foto JPG, PNG ou WebP de até 5 MB.');
        campoFoto.reportValidity();
        previaFoto.innerHTML = fotoOriginal;
        return;
    }

    const imagem = document.createElement('img');
    const enderecoFoto = URL.createObjectURL(arquivo);
    imagem.className = 'avatar-img';
    imagem.alt = 'Prévia da foto de perfil';
    imagem.width = 96;
    imagem.height = 96;
    imagem.onload = function () {
        URL.revokeObjectURL(enderecoFoto);
    };
    imagem.onerror = function () {
        URL.revokeObjectURL(enderecoFoto);
        campoFoto.setCustomValidity('Não foi possível abrir esta imagem. Escolha outra foto.');
        campoFoto.reportValidity();
        previaFoto.innerHTML = fotoOriginal;
    };
    imagem.src = enderecoFoto;
    previaFoto.innerHTML = '';
    previaFoto.appendChild(imagem);
}

const botoesFechar = document.querySelectorAll('[data-flash-close]');
for (let i = 0; i < botoesFechar.length; i++) {
    botoesFechar[i].addEventListener('click', function () {
        const mensagem = this.closest('.flash');
        if (mensagem) {
            mensagem.remove();
        }
    });
}

const formularios = document.querySelectorAll('[data-confirm]');
for (let i = 0; i < formularios.length; i++) {
    formularios[i].addEventListener('submit', function (evento) {
        const mensagem = this.getAttribute('data-confirm') || 'Tem certeza?';
        if (!window.confirm(mensagem)) {
            evento.preventDefault();
        }
    });
}

function doisDigitos(numero) {
    if (numero < 10) {
        return '0' + numero;
    }
    return String(numero);
}

function tempoDoVideo(segundos) {
    const horas = Math.floor(segundos / 3600);
    const minutos = Math.floor((segundos % 3600) / 60);
    const resto = segundos % 60;
    if (horas > 0) {
        return horas + ':' + doisDigitos(minutos) + ':' + doisDigitos(resto);
    }
    return minutos + ':' + doisDigitos(resto);
}

const campoVideo = document.querySelector('#arquivo_video');
const campoDuracao = document.querySelector('#duracao_cliente');
const textoDuracao = document.querySelector('[data-duration-preview]');

function detectarDuracao() {
    const arquivo = campoVideo.files[0];
    campoDuracao.value = '0';
    if (textoDuracao) {
        textoDuracao.textContent = 'Duração: detectando...';
    }
    if (!arquivo) {
        if (textoDuracao) {
            textoDuracao.textContent = '';
        }
        return;
    }

    const enderecoVideo = URL.createObjectURL(arquivo);
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = function () {
        const segundos = Math.max(0, Math.round(video.duration || 0));
        campoDuracao.value = String(segundos);
        URL.revokeObjectURL(enderecoVideo);
        if (textoDuracao) {
            textoDuracao.textContent = 'Duração detectada: ' + tempoDoVideo(segundos);
        }
    };
    video.onerror = function () {
        URL.revokeObjectURL(enderecoVideo);
        if (textoDuracao) {
            textoDuracao.textContent = 'A duração será verificada no servidor.';
        }
    };
    video.src = enderecoVideo;
}

if (campoVideo && campoDuracao) {
    campoVideo.addEventListener('change', detectarDuracao);
}

const campoCapa = document.querySelector('#thumbnail');
const previaCapa = document.querySelector('[data-thumb-preview]');

function mostrarPreviaCapa() {
    previaCapa.innerHTML = '';
    const arquivo = campoCapa.files[0];
    if (!arquivo) {
        return;
    }
    const imagem = document.createElement('img');
    const enderecoCapa = URL.createObjectURL(arquivo);
    imagem.alt = 'Prévia da thumbnail';
    imagem.onload = function () {
        URL.revokeObjectURL(enderecoCapa);
    };
    imagem.onerror = function () {
        URL.revokeObjectURL(enderecoCapa);
    };
    imagem.src = enderecoCapa;
    previaCapa.appendChild(imagem);
}

if (campoCapa && previaCapa) {
    campoCapa.addEventListener('change', mostrarPreviaCapa);
}
