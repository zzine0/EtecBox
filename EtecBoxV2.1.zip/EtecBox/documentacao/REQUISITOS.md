# Rastreabilidade — EtecBox

Este arquivo relaciona os recursos implementados aos arquivos desta entrega.

| Requisito | Implementação principal |
|---|---|
| RF01 Cadastrar usuário | `paginas/acesso/cadastro.php`, tabela `usuario` |
| RF02 Realizar login | `paginas/acesso/login.php`, `paginas/acesso/logout.php`, sessões PHP |
| RF03 Editar perfil | `paginas/conta/editar_perfil.php`, `paginas/canal/perfil.php` |
| RF04 Publicar vídeo | `paginas/videos/upload.php`, pasta `uploads/videos` |
| RF05 Identificar duração | `assets/js/app.js` + FFprobe em `includes/helpers.php` |
| RF06 Exibir página inicial | `paginas/inicio/home.php` |
| RF07 Assistir vídeo | `paginas/videos/video.php` + player HTML5 |
| RF08 Visualizar canal | `paginas/canal/perfil.php` |
| RF09 Inscrever-se | `paginas/canal/inscricao.php`, tabela `inscricao` |
| RF10 Registrar visualizações | `paginas/videos/video.php`, campo `visualizacoes` |
| RF11 Histórico | `paginas/historico/historico.php`, tabela `historico` |
| RF12 Gerenciar vídeos | `paginas/canal/meus_videos.php`, `paginas/videos/editar_video.php`, `paginas/videos/remover_video.php` |
| RF13 Tema claro e escuro | `paginas/conta/configuracoes.php`, `assets/css/style.css`, campo `tema` |
| RF14 Moderar conteúdo | `paginas/administracao/`, `paginas/videos/remover_video.php` |

## Regras de negócio

- RN01: e-mail `UNIQUE` no banco e validação em `paginas/acesso/cadastro.php`.
- RN02: `paginas/videos/upload.php` exige usuário autenticado.
- RN03: título e categoria são obrigatórios no formulário e no banco.
- RN04: edição e remoção verificam proprietário do vídeo.
- RN05: `paginas/canal/inscricao.php` impede seguir o próprio canal.
- RN06: índice `UNIQUE(id_seguidor,id_canal)` + `INSERT IGNORE`.
- RN07: administrador pode remover vídeos em `paginas/administracao/videos.php`.
- RN08: remoção é lógica (`status='removido'`) e vídeos removidos não são exibidos/reproduzidos.

## Fluxos previstos para avaliação

- T01 Cadastro válido: fluxo implementado.
- T02 E-mail duplicado: bloqueado por aplicação e banco.
- T03 Login: implementado com `password_verify`.
- T04 Upload: implementado com validação de MIME e banco.
- T05 Canal: perfil mostra foto, nome, inscritos e vídeos.
- T06 Inscrição: registrada uma única vez.
- T07 Gerenciamento: usuário não remove vídeo de outro.
- T08 Moderação: admin remove e o vídeo deixa de aparecer.
- T09 Tema: preferência é salva em `usuario.tema`.
- T10 Responsividade: CSS possui breakpoints para desktop, tablet e celular.

## Itens propositalmente fora desta versão

Nesta versão, comentários, curtidas, notificações, vídeos privados, múltiplas resoluções, aplicativo móvel e recomendação avançada não foram adicionados.


## Atualização de 18/09/2026

A interface e os exemplos foram revisados. O feed agora usa pesquisa, filtros e ordenação em lugar de carrosséis repetidos. Sobre, Créditos, identidade visual e administração de demonstrações foram adicionados. Consulte INSTALACAO.md e VERIFICACAO.txt para a entrega atual.
