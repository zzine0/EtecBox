# Instalação e atualização

## XAMPP — instalação nova

1. Extraia o ZIP e copie a pasta `EtecBox` para `C:\xampp\htdocs\etecbox`.
2. Inicie Apache e MySQL no painel do XAMPP.
3. Abra `http://localhost/etecbox/instalacao/setup.php`.
4. No XAMPP padrão, use host `127.0.0.1`, porta `3306`, banco `etecbox`, usuário `root` e senha vazia. Se seu MySQL usa outros dados, informe-os.
5. Clique em **Criar banco e instalar** e depois abra `http://localhost/etecbox/`.

O instalador cria `config/config.local.php` e `config/installed.lock`. Os arquivos SQL e as seis demonstrações já estão incluídos.

É necessário PHP 8 ou superior com PDO MySQL e Fileinfo. GD permite recortar a foto de perfil; FFprobe detecta a duração no servidor quando disponível. Para arquivos grandes, configure `upload_max_filesize=500M` e `post_max_size=510M` no PHP e reinicie o Apache.

## Docker — instalação nova

Com o Docker em execução, abra o terminal na pasta que contém `compose.yaml` e execute:

```sh
docker compose up -d --build
docker compose ps
```

A primeira preparação pode demorar. Aguarde os serviços ficarem saudáveis e abra `http://localhost:8080`.

O banco é preparado automaticamente. Não é necessário executar o instalador do XAMPP. Os dois serviços devem ser iniciados pelo Compose. Os valores opcionais de configuração estão em `.env.example`.

Se houver falha de conexão, consulte [a manutenção do Docker](MANUTENCAO_DOCKER.md).

## Contas de demonstração

| Tipo | E-mail | Senha |
| --- | --- | --- |
| Administrador | `admin@etecbox.local` | `admin123` |
| Aluno | `aluno@etecbox.local` | `etecbox123` |
| Ana | `ana@etecbox.local` | `etecbox123` |

O professor pode criar uma conta para testar envio de vídeo e edição de perfil. Use a conta administrativa para acessar a moderação.

## Importação manual — somente instalação nova

Como alternativa ao instalador do XAMPP, importe `database/etecbox.sql` pelo phpMyAdmin e confira a configuração em `config/config.php`. Os arquivos `schema_only.sql` e `seed.sql` são usados pelo instalador; não precisam ser importados novamente depois do SQL completo.

## Atualizar uma instalação existente

Esta versão mudou a localização das páginas. O endereço inicial continua sendo a raiz do site; links antigos salvos para páginas internas precisam ser atualizados.

1. Faça uma cópia da pasta atual e do banco.
2. Preserve `.env`, `config/config.local.php`, `config/installed.lock` e todos os seus arquivos em `uploads/`.
3. Para evitar misturar páginas antigas e novas, prepare uma pasta com o conteúdo completo desta entrega e copie para ela os arquivos preservados. Mantenha os uploads de demonstração incluídos e os seus uploads próprios.
4. Depois do backup, coloque essa pasta no local do projeto antigo, usando o mesmo nome de pasta.
5. No Docker, use o mesmo nome de projeto Compose e execute `docker compose up -d --build`. Se antes usava `-p`, mantenha o mesmo valor.
6. No XAMPP, abra o endereço inicial que já utilizava. Não execute o instalador novamente.

Não reimporte o SQL nem exclua os volumes do Docker para atualizar. O banco e os nomes dos arquivos enviados não mudaram.

## Diagnóstico

- XAMPP: `http://localhost/etecbox/instalacao/diagnostico.php`.
- Docker: `http://localhost:8080/instalacao/diagnostico.php`.

A página confere conexão, tabelas e permissões. Os limites dos testes realizados estão em `VERIFICACAO.txt`.
