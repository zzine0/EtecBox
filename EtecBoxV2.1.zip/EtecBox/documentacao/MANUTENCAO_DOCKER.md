# Conexão com o banco no Docker

## Preparar a instalação

1. Guarde uma cópia da pasta atual e do banco.
2. Para atualizar uma instalação existente, siga primeiro a seção de atualização em `INSTALACAO.md`. A organização das páginas mudou; preserve suas configurações, uploads e o nome do projeto Compose.
3. Se você personalizou as credenciais no Compose antigo, coloque esses mesmos valores em um `.env`, usando `.env.example` como modelo. O novo Compose usa os mesmos valores nos dois serviços. Não substitua senhas existentes pelos exemplos.
4. Na pasta que contém `compose.yaml`, execute:

```sh
docker compose up -d --build
docker compose ps
docker compose logs --tail=80 mysql etecbox
```

O primeiro build pode demorar. Espere os serviços ficarem `healthy` e a mensagem `[EtecBox] Banco pronto.` aparecer. Abra <http://localhost:8080> (ou a porta definida em `ETECBOX_HTTP_PORT`).

Use o mesmo nome de projeto Compose de antes. Se usava `docker compose -p algum_nome`, mantenha `-p algum_nome` em todos os comandos. Trocar a pasta/nome pode selecionar volumes novos e fazer os dados antigos parecerem ausentes.

**Não use `docker compose down -v`, não exclua os volumes e não reimporte o SQL completo para resolver a conexão.** O pacote mantém os volumes `etecbox_mysql_data` e `etecbox_uploads`.

No Docker Desktop, iniciar somente `etecbox-app` não inicia automaticamente o banco. Use o comando Compose acima para iniciar os dois serviços.

## Se aparecer “Access denied”, “unhealthy” ou senha recusada

Um volume antigo conserva os usuários e as senhas com que foi criado. Mudar `MYSQL_PASSWORD` ou `MYSQL_ROOT_PASSWORD` no Compose não altera automaticamente as contas já salvas.

Se souber a senha atual da conta da aplicação, coloque-a em `ETECBOX_DB_PASS` no `.env` e execute novamente `docker compose up -d --build`. Para uma senha com `$`, `#` ou espaços, use aspas simples no `.env`.

Se a conta estiver ausente, com permissão incorreta ou você precisar alinhá-la à senha configurada, use o reparo incluído:

```sh
docker compose up -d mysql
docker compose exec mysql bash /opt/etecbox/reparar-banco.sh
docker compose up -d --build
```

Execute o reparo depois de o MySQL estar aceitando conexões; o container pode estar `unhealthy` por senha incorreta e ainda permitir esse comando. O reparo:

- autentica como root dentro do próprio container;
- tenta a senha root configurada; se for diferente da existente, solicita a senha atual sem exibi-la;
- cria o banco apenas se faltar;
- cria/atualiza **somente a conta configurada em `MYSQL_USER`, no host `%`**, alinhando sua senha a `MYSQL_PASSWORD` e concedendo acesso ao banco configurado;
- não altera a senha root, as contas de login do site, os registros ou os uploads.

O reparo muda a credencial da conta de banco usada pela EtecBox. Se outro sistema compartilha essa conta, ele também precisará usar a mesma senha. O script não executa automaticamente durante os reinícios.

É necessária a senha root atual para esse reparo. Se ela foi perdida, se o MySQL não inicia ou se há erro de corrupção/versão incompatível do volume, guarde os logs e o volume para investigar o caso específico. Não apague o volume para contornar o erro.

## Verificar a conexão

Com a aplicação em execução:

```sh
docker compose exec etecbox php docker/docker-init.php --check
```

Se o MySQL falhou no healthcheck e a aplicação não iniciou:

```sh
docker compose build etecbox
docker compose run --rm --no-deps etecbox php docker/docker-init.php --check
```

`--check` é somente leitura: testa autenticação, banco e as cinco tabelas. Não instala nem repara dados. Os logs diferenciam servidor indisponível, credenciais recusadas, falta de banco/tabelas e falta de permissões.

A página <http://localhost:8080/instalacao/diagnostico.php> usa a mesma configuração da aplicação. `/docker/health.php` devolve HTTP 200 quando consegue ler as tabelas e HTTP 503 quando não consegue, sem revelar credenciais.

## O que foi corrigido

- `mysqladmin ping` foi substituído por uma consulta autenticada por TCP com a conta da aplicação. O ping antigo podia indicar sucesso mesmo com senha recusada e durante a inicialização temporária por socket.
- O site e `docker/docker-init.php` agora usam a mesma configuração e conexão. Variáveis Docker têm prioridade sobre `config.local.php`; no XAMPP, o arquivo local continua funcionando.
- As credenciais são definidas uma única vez no `.env` e repassadas aos dois serviços. O host interno é `mysql:3306`; `localhost` dentro da aplicação aponta para o próprio container.
- O inicializador aguarda falhas transitórias por até 180 segundos, configuráveis, e informa erros de autenticação sem ficar repetindo tentativas inúteis.
- A instalação do schema ficou a cargo do PHP; foi removida a segunda importação automática do SQL completo no serviço MySQL. Banco ausente é criado apenas se o usuário já tiver permissão.
- Tabelas ausentes são criadas com `IF NOT EXISTS`. Demonstrações são instaladas apenas quando as cinco tabelas estão vazias, em uma transação. Reinícios preservam alterações e exclusões feitas no site.
- O healthcheck da aplicação usa `/docker/health.php`, e o feed devolve HTTP 503 se perder o banco.
- O `.env` não entra na imagem da aplicação, e a inicialização administrativa não pode ser chamada por HTTP.

## Limites da validação

Veja `VERIFICACAO.txt`. A integração foi testada com PHP e MariaDB locais; o ambiente de trabalho não possui Docker Engine. O build PHP 8.3/Apache + MySQL 8.4 e o erro específico no seu computador ainda precisam ser confirmados pelos comandos acima.

## Referências

- [Ordem de inicialização no Compose](https://docs.docker.com/compose/how-tos/startup-order/)
- [Imagem oficial MySQL: variáveis e volumes existentes](https://github.com/docker-library/docs/blob/master/mysql/README.md#environment-variables)
- [MySQL: comportamento de mysqladmin ping](https://dev.mysql.com/doc/refman/8.4/en/mysqladmin.html)
