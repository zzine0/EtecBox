REGISTRO ANTERIOR — os caminhos deste arquivo pertencem à versão antiga. Para esta entrega, use ../../README.md e ../INSTALACAO.md.

# EtecBox — Versão escolar simplificada

A EtecBox é uma plataforma escolar de streaming de vídeos criada para reunir trabalhos, apresentações, materiais de estudo e projetos da ETEC.

Leia **ATUALIZACAO.txt** antes de atualizar uma instalação existente.

## Organização do código

O visual, as páginas e as funções da versão anterior foram mantidos. O código usa PHP procedural e JavaScript puro, sem framework.

- Funções e variáveis principais têm nomes em português.
- Condições usam `if`, `else` e `switch`; repetições usam `for` e `foreach`.
- A busca monta a consulta em etapas, com variáveis separadas.
- Consultas e gravações antes encadeadas foram separadas em passos.
- O JavaScript usa funções comuns para menu, tema e prévias.
- O CSS está organizado com uma propriedade por linha.
- Os arquivos de código não têm comentários. A primeira linha dos scripts shell indica o programa que os executa.

Para estudar, comece por `cadastro.php`, `login.php`, `index.php` e `upload.php`. As funções compartilhadas estão em `includes/helpers.php`; a conexão fica em `config/conexao.php`. `includes/header.php` e `includes/footer.php` montam as partes comuns das telas.

As senhas continuam protegidas por hash, os formulários usam um token de sessão e as consultas usam parâmetros. O schema do banco e os nomes das páginas foram mantidos, então a atualização não exige recriar os dados. Copie todos os arquivos novos juntos, pois os nomes das funções internas mudaram.

## Tecnologias
- PHP 8+
- MySQL ou MariaDB
- HTML5
- CSS3
- JavaScript simples
- HTML5 Video

## Funcionalidades implementadas
- Cadastro de usuário
- Login e logout
- E-mail único
- Perfil/canal
- Edição de nome e foto
- Upload de vídeo
- Upload de thumbnail
- Detecção automática de duração (FFprobe no servidor quando disponível; navegador como fallback)
- Feed de vídeos com busca por título/canal/categoria, filtros, ordenação e paginação
- Player HTML5
- Visualizações
- Histórico
- Inscrição/cancelamento
- Gerenciamento dos próprios vídeos
- Edição de título, categoria e thumbnail
- Remoção lógica de vídeo
- Tema claro/escuro persistido no banco
- Painel administrativo
- Listagem de usuários
- Moderação de vídeos
- Validações no servidor
- Prepared statements
- password_hash/password_verify
- CSRF
- Interface responsiva e acessível

## Docker

Leia **CORRECAO_DOCKER.md** para aplicar a atualização preservando os dados e reparar credenciais de volumes antigos.

```sh
docker compose up -d --build
```

Depois que os dois serviços estiverem saudáveis, abra <http://localhost:8080>.
Configurações opcionais ficam em `.env` (modelo: `.env.example`). O host interno do banco é `mysql`, na porta `3306`.

## Instalação mais fácil (XAMPP)

1. Instale e abra o XAMPP.
2. Inicie **Apache** e **MySQL**.
3. Copie a pasta `etecbox` para:
   `C:\xampp\htdocs\etecbox`
4. Abra no navegador:
   `http://localhost/etecbox/setup.php`
5. Use:
   - Host: `127.0.0.1`
   - Porta: `3306`
   - Banco: `etecbox`
   - Usuário: `root`
   - Senha: deixe vazia no XAMPP padrão
6. Clique em **Criar banco e instalar**.
7. Abra:
   `http://localhost/etecbox/`

## Instalação por phpMyAdmin

Se preferir:
1. Abra phpMyAdmin.
2. Importe `database/etecbox.sql`.
3. Confira `config/config.php`.
4. Abra a aplicação.

## Contas de demonstração

Administrador:
- E-mail: `admin@etecbox.local`
- Senha: `admin123`

Aluno:
- E-mail: `aluno@etecbox.local`
- Senha: `etecbox123`

Ana (conta fictícia):
- E-mail: `ana@etecbox.local`
- Senha: `etecbox123`

## Vídeos de demonstração
O pacote inclui seis clipes educativos originais de 36 segundos em `assets/demo`, com capas e identificação de demonstração. Instalações novas recebem os exemplos pelo seed. Em uma instalação existente, use **Administração > Demonstrações**; executar novamente não duplica os exemplos. Os clipes antigos em `uploads/videos` foram preservados para compatibilidade.

## Interface e identificação

- Sobre e Créditos acessíveis no menu lateral.
- Nomes da equipe configuráveis em `config/projeto.php`.
- Logo em SVG e PNG, marca horizontal e banner em `assets/img`.
- Material para Instagram em `divulgacao`.
- Prévia de tema antes de salvar.
- Foto de perfil contida por CSS; PHP/GD faz recorte central de 512 × 512 quando disponível.

## Uploads
O PHP/Apache precisa ter permissão de escrita em:
- `uploads/videos`
- `uploads/thumbnails`
- `uploads/perfis`

No XAMPP/Windows isso normalmente funciona sem configuração extra.

## Limites
A aplicação aceita:
- Vídeos MP4, WebM e OGG
- Thumbnails/fotos JPG, PNG e WebP
- Até 500 MB por vídeo na aplicação
- Até 5 MB por imagem

Para arquivos grandes, o `php.ini` também precisa permitir o tamanho desejado:
- `upload_max_filesize`
- `post_max_size`

Após alterar o `php.ini`, reinicie o Apache.

## Duração do vídeo
A aplicação tenta detectar a duração de duas formas:
1. FFprobe/FFmpeg no servidor, se instalado.
2. Metadata do `<video>` no navegador, automaticamente, antes do envio.

## Escopo
O sistema segue a documentação escolar da EtecBox. Comentários, curtidas, notificações, vídeos privados, múltiplas resoluções, aplicativo móvel e algoritmos avançados de recomendação permanecem fora desta primeira versão.

## Verificação desta atualização

Consulte `VERIFICACAO.txt` para saber quais fluxos foram efetivamente verificados e os limites do ambiente de teste.
