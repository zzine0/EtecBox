# Organização dos arquivos

Os caminhos abaixo partem da pasta principal `EtecBox`.

## Telas e ações

| Área | Pasta | Arquivos e função |
| --- | --- | --- |
| Acesso | `paginas/acesso/` | `login.php`: entrar; `cadastro.php`: criar conta; `logout.php`: sair. |
| Início | `paginas/inicio/` | `home.php`: vídeos, pesquisa, filtros e ordenação; `404.php`: página não encontrada. |
| Conta | `paginas/conta/` | `configuracoes.php`: tema e saída da conta; `editar_perfil.php`: nome e foto. |
| Vídeos | `paginas/videos/` | `video.php`: assistir; `upload.php`: publicar; `editar_video.php`: editar; `remover_video.php`: remover. |
| Canal | `paginas/canal/` | `perfil.php`: canal; `meus_videos.php`: publicações próprias; `inscricao.php`: seguir ou deixar de seguir. |
| Histórico | `paginas/historico/` | `historico.php`: vídeos assistidos. |
| Administração | `paginas/administracao/` | `index.php`: resumo; `usuarios.php`: usuários; `videos.php`: moderação; `demos.php`: demonstrações; `_nav.php`: menu da área. |
| Informações | `paginas/informacoes/` | `sobre.php`: apresentação do site; `creditos.php`: equipe e créditos. |

## Arquivos compartilhados

| Arquivo | Função |
| --- | --- |
| `config/config.php` | Dados gerais e configuração do banco. |
| `config/conexao.php` | Abre a conexão PDO com MySQL/MariaDB. |
| `config/projeto.php` | Identificação do projeto e da equipe. |
| `includes/bootstrap.php` | Carrega configuração, sessão e funções comuns. |
| `includes/auth.php` | Identifica o usuário e verifica permissões. |
| `includes/helpers.php` | Endereços, formulários, mensagens, datas e uploads. |
| `includes/header.php` | Cabeçalho, pesquisa e menu lateral. |
| `includes/footer.php` | Rodapé. |
| `includes/video_card.php` | Cartão de vídeo usado nas listagens. |
| `includes/icons.php` | Ícones do site. |
| `assets/css/style.css` | Aparência e adaptação das telas. |
| `assets/js/app.js` | Menu, temas, prévias de arquivos e duração do vídeo. |

A conexão e a validação de sessão são compartilhadas. Não é necessário copiar `conexao.php` ou criar um `banco.php` em cada área.

## Banco e instalação

- `database/schema_only.sql`: cria as tabelas.
- `database/seed.sql`: dados iniciais e contas de demonstração.
- `database/etecbox.sql`: instalação completa para importação manual em banco novo.
- `instalacao/setup.php`: instalação pelo XAMPP.
- `instalacao/diagnostico.php`: verifica PHP, banco e permissões de escrita.
- `docker/docker-init.php`: prepara o banco no Docker.
- `docker/health.php`: verifica se o banco está disponível.
- `docker/docker-entrypoint-etecbox.sh`: inicializa o banco e inicia o Apache.
- `docker/reparar-banco.sh`: reparo de credenciais, quando necessário.

## Relação com a referência enviada

A divisão por área foi aproveitada. O login continua único para aluno e administrador. O perfil já funciona como canal, criado junto com a conta, então não existem telas separadas para criar canal ou editar canal. A edição do nome e da foto fica em Conta. O envio foi mantido como `upload.php`.

## Materiais e registros

`materiais/telas/` reúne as capturas anteriores da interface. `materiais/divulgacao/` contém as artes e a legenda para Instagram. `materiais/previa.html` mostra capturas estáticas; não executa login, banco ou uploads.

`documentacao/historico/` guarda os guias anteriores e a referência original. Eles documentam versões anteriores; use o README principal e o guia de instalação atual para abrir esta entrega.

## Sugestão de leitura do código

Comece por `config/conexao.php`, depois `paginas/acesso/cadastro.php`, `paginas/acesso/login.php` e `paginas/inicio/home.php`. Em seguida, veja `paginas/videos/upload.php` e `paginas/videos/video.php`. Os arquivos permanecem em PHP procedural e JavaScript puro, sem comentários no código.
