<?php

$config = [
    'db_host' => '127.0.0.1',
    'db_port' => '3306',
    'db_name' => 'etecbox',
    'db_user' => 'root',
    'db_pass' => '',
    'max_video_bytes' => 500 * 1024 * 1024,
    'max_image_bytes' => 5 * 1024 * 1024
];

$arquivoLocal = __DIR__ . '/config.local.php';
if (is_file($arquivoLocal)) {
    $configuracaoLocal = require $arquivoLocal;
    if (is_array($configuracaoLocal)) {
        $config = array_merge($config, $configuracaoLocal);
    }
}

foreach (['host', 'port', 'name', 'user', 'pass'] as $chave) {
    $valor = getenv('ETECBOX_DB_' . strtoupper($chave));
    if ($valor !== false) {
        $config['db_' . $chave] = $valor;
    }
}

define('ETECBOX_DOCKER', getenv('ETECBOX_DOCKER') === '1');
define('APP_NAME', 'EtecBox');
define('APP_TAGLINE', 'Compartilhe. Inspire. Crie.');
define('DB_HOST', (string) $config['db_host']);
define('DB_PORT', (string) $config['db_port']);
define('DB_NAME', (string) $config['db_name']);
define('DB_USER', (string) $config['db_user']);
define('DB_PASS', (string) $config['db_pass']);
define('MAX_VIDEO_BYTES', (int) $config['max_video_bytes']);
define('MAX_IMAGE_BYTES', (int) $config['max_image_bytes']);
