<?php

return [
    'instituicao' => 'ETEC Jardim Ângela',
    'ano' => '2026',
    'equipe' => [],
    'orientacao' => ''
];
