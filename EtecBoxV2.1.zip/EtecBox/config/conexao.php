<?php

function abrirConexao($selecionarBanco = true)
{
    if (!extension_loaded('pdo_mysql')) {
        throw new RuntimeException(
            'A extensão pdo_mysql do PHP não está habilitada. No XAMPP ela normalmente já vem ativa.'
        );
    }

    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8mb4';
    if ($selecionarBanco) {
        $dsn .= ';dbname=' . DB_NAME;
    }

    return new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_TIMEOUT => 3
    ]);
}

function erroDoBanco($erro)
{
    $codigo = 0;
    if ($erro instanceof PDOException) {
        $codigo = (int) ($erro->errorInfo[1] ?? 0);
    }
    switch ($codigo) {
        case 1045:
            return 'MySQL recusou o usuário ou a senha. Confira o .env e as credenciais do volume existente; veja documentacao/MANUTENCAO_DOCKER.md.';
        case 1044:
        case 1142:
            return 'O usuário não tem permissão no banco configurado. Confira o nome do banco e as permissões; veja documentacao/MANUTENCAO_DOCKER.md.';
        case 1049:
            return 'O banco configurado ainda não existe. Execute o inicializador ou o reparo descrito em documentacao/MANUTENCAO_DOCKER.md.';
        case 2002:
        case 2003:
        case 2005:
        case 2006:
        case 2013:
            return 'MySQL indisponível. No Docker, inicie os dois serviços com docker compose up -d --build; o host interno deve ser mysql, na porta 3306.';
        case 1524:
        case 2054:
            return 'O método de autenticação do usuário não é compatível com o servidor/cliente. Veja o reparo de credenciais em documentacao/MANUTENCAO_DOCKER.md.';
        case 1146:
            return 'Há tabelas ausentes. Execute docker/docker-init.php para completar a estrutura.';
        default:
            if ($codigo > 0) {
                return 'Falha no banco (código MySQL ' . $codigo . '). Consulte os logs do serviço mysql.';
            }
            return 'Não foi possível verificar o banco. Confira a configuração e a extensão pdo_mysql.';
    }
}

function verificarTabelas($conexao)
{
    foreach (['usuario', 'categoria', 'video', 'inscricao', 'historico'] as $tabela) {
        $conexao->query('SELECT 1 FROM `' . $tabela . '` LIMIT 0');
    }
}

$conexao = null;

function banco()
{
    global $conexao;
    if ($conexao !== null) {
        return $conexao;
    }

    try {
        $conexao = abrirConexao();
    } catch (PDOException $erro) {
        error_log('EtecBox: ' . erroDoBanco($erro));
        throw new RuntimeException(
            ETECBOX_DOCKER
                ? 'Não foi possível conectar ao banco EtecBox. Consulte os logs do Docker e documentacao/MANUTENCAO_DOCKER.md.'
                : 'Não foi possível conectar ao banco EtecBox. Confira os dados em instalacao/setup.php ou config/config.local.php.',
            0,
            $erro
        );
    }

    return $conexao;
}
